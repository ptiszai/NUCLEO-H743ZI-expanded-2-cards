#ifndef _TRANSFORM_TESTS_H_
#define _TRANSFORM_TESTS_H_

/*--------------------------------------------------------------------------------*/
/* Test/Group Declarations */
/*--------------------------------------------------------------------------------*/
JTEST_DECLARE_GROUP(cfft_tests);
JTEST_DECLARE_GROUP(cfft_family_tests);
JTEST_DECLARE_GROUP(dct4_tests);
JTEST_DECLARE_GROUP(rfft_tests);
JTEST_DECLARE_GROUP(rfft_fast_tests);

#endif /* _TRANSFORM_TESTS_H_ */
