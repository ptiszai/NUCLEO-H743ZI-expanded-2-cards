#ifndef __DIGIT_INPUT_H
#define __DIGIT_INPUT_H

#include "defines.h"

typedef struct
{
	char status;
	char status_prev;
	char din[DIGITIN_LENGTH];
	char din_prev[DIGITIN_LENGTH];
	bool change;
} DIGITIN;

void Init_digIn(void);
void DigIn_exec(void);
void DigIn_force_sended(void);

#endif // __DIGIT_INPUT_H
