#ifndef __MY_MALLOC_FREE_H
#define __MY_MALLOC_FREE_H
#include <string.h>
#define MNUM_BLOCKS 128
typedef struct
{
	void * address;
	size_t size;
} BlockEntry;

void *mMalloc(size_t size);
void mFree(void *blockToFree);
void mClearTable(void);

#endif // __DIGIT_INPUT_H
