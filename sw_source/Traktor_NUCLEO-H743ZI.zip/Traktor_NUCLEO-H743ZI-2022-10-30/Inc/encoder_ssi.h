/*
 * Encoder: encoder_ssi.h
 *
 *  Created: 2021.01.23. 
 *  Author: tiszai
 */
#pragma once
void EncoderSSI_init(void);
void Encoder_SET(void);
void EncoderSSI_executor(void);