#ifndef __USB_PROCESS_H
#define __USB_PROCESS_H

#define USB_RX_DATA_SIZE  (65)
#define CMD_MIN_LEN			4

#define CMD_START_CHAR_RX		'$'
#define SC_MODE			'S' // SC, parancs mode
#define E_MODE			'E' // E, epprom data read/weite
#define END_CHAR			'\r' 
#define CMD_START_CHAR_TX		'!'
#define COMPUTER_ID_CHAR		'C'
#define DIGITIN_ID_CHAR		'D' // digit
#define ANALOG_ID_CHAR		'A' // analog
#define ACK_ID_CHAR			'X' // none
#define ANALOG_GAZ_CHAR		'g'
#define ANALOG_FEK_CHAR		'f'
#define ANALOG_FEK_GAZ_CHAR		'A'
#define ANALOG_KORMANY_CHAR		'S' // steering
#define FREQ_ID_CHAR		'F'
#define CMD_RESET		'R'		// reset
#define CMD_STAT		'G'		// utolso allapot
#define CMD_RAW_DATA	'd'		// keri az analogtol a gaz, fek adc raw adatokat, es kormany
#define CMD_ENC_PSET	'S'		// encoder SET commend
#define CMD_ACK			'A'		// ack
#define CMD_EERD_F		'F'		// eeprom rd float
#define CMD_EEWR_F		'W'		// eeprom wr float
#define CMD_EERD_S		'r'		// eeprom rd short
#define CMD_EEWR_S		'w'		// eeprom wr short

void Init_usb(void);
void USBH_exec();
void USBH_send(uint8_t* data, uint16_t size);
void USBH_copyDataToTxBuffer(uint8_t* buffer, uint16_t len);
#endif // __USB_PROCESS_H

