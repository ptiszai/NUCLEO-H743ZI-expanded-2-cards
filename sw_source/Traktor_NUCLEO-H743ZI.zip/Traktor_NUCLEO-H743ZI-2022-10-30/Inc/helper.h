/*
 * helper.h
 *
 *  Created on: 2019.06.28.
 *      Author: tiszai istvan
 */

#ifndef HELPER_H
#define	HELPER_H

#include <stdint.h>
int strLength(const char* data);
void hextoascii(char ch, char* ascii);
#if 0
inline void hex2ascii(uint16_t myInt, char* buf);
#endif
void uint16TOuint8Array(uint16_t* src, uint8_t* dest);
void uint32TOuint8Array(uint32_t* src, uint8_t* dest);
char asciitohex(char ch);
uint16_t HexArrayTouint16(uint8_t pwH, uint8_t pwL);
void uint16ToAsciiarray(uint16_t src, uint8_t* dest);
uint16_t  uint16ToAsciiuint16(uint16_t src);
uint16_t  asciiuint16Touint16(uint16_t src);
uint16_t CRC16Algorithm(uint16_t crc, uint8_t Ch);
void uint16ToAscii(uint16_t src, char* ascii);
uint8_t genCRC8bits(uint8_t *data, uint16_t len);
bool CreatCRCToSend(char* crcBuffer, int len);
void mem_cpy(void* dst, const void* src, uint32_t cnt);
void mem_set(void* dst, int val, uint32_t cnt);
int mem_cmp(const void* dst, const void* src, uint32_t cnt);

#endif	/* HELPER_H */

