/***************************************************************************
 *    general list queue.
 *    modul name: list.h
 *    author:         Tiszai Istvan.
 *    company: Brace bt.
 *    Environment: kernel and user.
 * $Log: list.h,v $
 * Revision 1.2  2003/10/10 17:57:01  Tiszai Isvan
 * first
 *
 ***************************************************************************/
#ifndef  LIST_H
#define  LIST_H


/********************* type definitions ************************************/
typedef struct _LIST
{
	struct _LIST* head;
	struct _LIST* tail;
	void*   block;
	short   count;
} LIST, *PLIST;

typedef struct _PACKET
{
    void* data;
    int length;
} PACKET, *PPACKET;

/********************* functions declaration *******************************/

int ListInit( PLIST );
int ListInsertTail( PLIST, void* );
void* ListRemoveHead( PLIST );
void* ListRemoveTail( PLIST );
int ListInsertHead( PLIST, void* );
int ListClear( PLIST );
short ListGetCount( PLIST );
//#define ExFreePool(t) free(t)
//#define EXAllocatePool( a ) malloc(a)
#define TRUE 1
#define FALSE 0

#endif