/*
 * EEprom: CP_eeprom_24LC1026.h
 *
 *  Created: 2020.09.26. 
 *  Author: tiszai
 */
#pragma once

// eeprom address
#define EE_VAIDATE 0			// 2 byte 
#define EE_VERSION 2			// 2 byte (short) + 1 CRC
#define EE_GAZ_SZAZ_MAX 5		// 2 byte (short) + 1 CRC
#define EE_GAZ_ROW_MAX 8 		// 2 byte (short) + 1 CRC
#define EE_GAZ_SZAZ_MIN 11		// 2 byte (short) + 1 CRC
#define EE_GAZ_ROW_MIN 14		// 2 byte (short) + 1 CRC
#define EE_FEK_MM_MAX 17		// 2 byte (short) + 1 CRC
#define EE_FEK_ROW_MAX 20 		// 2 byte (short) + 1 CRC
#define EE_FEK_MM_MIN 23		// 2 byte (short) + 1 CRC
#define EE_FEK_ROW_MIN 26		// 2 byte (short) + 1 CRC
#define EE_KORMANY_FOK_MAX 29 	// 2 byte (short) + 1 CRC
#define EE_KORMANY_IMP_MAX 32 	// 2 byte (short) + 1 CRC
#define EE_KORMANY_FOK_MIN 35	// 2 byte (short) + 1 CRC
#define EE_KORMANY_IMP_MIN 38	// 2 byte (short) + 1 CRC
#define EE_END			41	

#define EE_MAX_ADDRESS_ARRAY_INDEX 15


typedef enum _ee_dev_address
{
	NONEEaddr = 0,
	ONEEEaddr = 1,
	TWOEEaddr = 2
} EEDEVICEADDRESS;

bool EE_Init(void);
bool eE_test(EEDEVICEADDRESS EEAddress);
bool EE_WriteString(EEDEVICEADDRESS EEAddress, const char* datastr, uint16_t wraddr);
bool EE_WriteUint16(EEDEVICEADDRESS EEAddress, uint16_t wrdata, uint16_t wraddr);
bool EE_ReadUint16(EEDEVICEADDRESS EEAddress, uint16_t* rddata, uint16_t rdaddr);
bool EE_WriteUint32(EEDEVICEADDRESS EEAddress, uint32_t wrdata, uint16_t wraddr);
bool EE_ReadUint32(EEDEVICEADDRESS EEAddress, uint32_t* rddata, uint16_t rdaddr);
bool EE_WriteFloat(EEDEVICEADDRESS EEAddress, float wrdata, uint16_t wraddr);
bool EE_ReadFloat(EEDEVICEADDRESS EEAddress, float* rddata, uint16_t rdaddr);
bool EE_ReadBin(EEDEVICEADDRESS EEAddress, uint8_t* rddata, uint16_t rdaddr, uint16_t* len);
bool EE_WriteBin(EEDEVICEADDRESS EEAddress, uint8_t* wrdata, uint16_t wraddr, uint16_t len);
bool EE_test(void);
bool EE_SetFirst(void);
bool EE_IsEmpty(void);
short EE_GetAddressFromArray(short index);

