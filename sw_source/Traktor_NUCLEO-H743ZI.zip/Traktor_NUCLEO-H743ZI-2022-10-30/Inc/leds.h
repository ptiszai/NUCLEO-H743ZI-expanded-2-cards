#ifndef __LEDS_H
#define __LEDS_H
#include "defines.h"

void Led1(bool on);
bool IsTurnOn_led1(void);
void Led2(bool on);
bool IsTurnOn_led2(void);
void Led3(bool on);
bool IsTurnOn_led3(void);
void LedsBlink(int delay, int count);
void Test(bool on);
void TestToggle(void);
void Test1(bool on);
void Test1Toggle(void);
#endif // __LEDS_H
