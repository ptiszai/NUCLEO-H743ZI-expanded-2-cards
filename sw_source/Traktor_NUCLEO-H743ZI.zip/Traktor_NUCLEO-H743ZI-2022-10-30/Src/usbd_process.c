/*
 * usbd_process.c
 *
 *  Created: 2020.06.22. 
 *  Author: tiszai
 */ 
/* Parancsok:
 * PC->Card
 * parancs mode:
 * '$','X','Y',CRC-16,'\r'
 * X: D, A: D: digit card, A: analog card.
 * Y: parancsok: R - reset, G - utolso allapot stb.
 * CRC-16: 4 byte, CRC polinom: 0x8005, NO reverse data bytes, NO reverse CRC result before Final XOR
 * Honlap a CRC-16 számításhoz: http://www.zorc.breitbandkatze.de/crc.html
 * '\r': (0x0D) : vége keret byte (nem ASCII)
 * '$','A','d',CRC-16,'\r' - keri az analogtol a gaz, fek adc raw adatokat
 * valasz:  '!','A',d,:gaz:fek:,CRC-16,'\r'
 * 
 * EEprom:
 * '$','X','Y':AAAA:DDDD:CRC-16,'\r'
 *  X: D, A: D: digit card, A: analog card.
 *  Y: W - eeprom wr float, F - eeprom rd float, w - eeprom wr short, r - eeprom rd short
 *  AAAA: eeprom address index
 *  DDDD: eeprom data only wr
 *  
 * Card->PC:
 * '!','X',ST,YYYY...,CRC-16,'\r',
 * X: D, A:  D: digit card, A: analog card.
 * ST: status, digit card: 1 byte 0-9; analog card: gaz es fek: 'A', kormany: 'k'
 * YYYY...: adatok.
 * 
 * Ack or not Ack
 * '!','X','A','Y',CRC-16,'\r',
 *  X: none
 *  Y: 1 - ack, 0 - no ack
 * 
 ** EEprom:
 *  '!','X','Y':AAAA:DDDD:CRC-16,'\r'
 *  X: D, A: D: digit card, A: analog card.
 *  Y: F - eeprom rd float, r - eeprom rd short
 *  AAAA: eeprom address index rd
 *  DDDD: eeprom data only rd
 */

#include <stdlib.h>
#include <string.h>
#include "defines.h"
#include "usbd_cdc_if.h"
#include "usbd_process.h"
#include "leds.h"
#include "helper.h"
#include "list.h"
#include "stm32h7xx_it.h"
#include "myMallocFree.h"	
#include "eeprom.h"
#include "adc.h"
#include "encoder_ssi.h"
#if DIGIN
#include "digitInput.h"
#endif

// public variables
uint8_t  USBRxBuffer[USB_RX_DATA_SIZE];
uint8_t* ptrUSBRxBuffer = &USBRxBuffer[0];
uint32_t USBprevRxCount = 0;
uint32_t USBRxBufLen = 0;
uint32_t USBRxBufLastLen = 0;
LIST USB_channelList;
bool tx_ready_timeout = false;
// private variables
static uint16_t tx_length;
//static uint8_t tx_buffer[64];
static CHANNELtype* USB_channel_current = NULL;
// private declarations
 static uint8_t send(uint8_t* buf, uint16_t len);

//----------------------------
// private functions
//----------------------------
 static uint8_t send(uint8_t* buf, uint16_t len)
{
	uint8_t _result = USBD_OK;
	int ii = 0;
	
	while ((_result = CDC_Transmit_FS(buf, len)) != USBD_OK)
	{
		if (ii == 10)
			break;
		HAL_Delay(50);
		ii++;
	}
	if (_result != USBD_OK)
	{
		
	}	
	return _result;
}

//----------------------------
static void sendAckOrNotAck(bool ack_a)
{
	if (USB_channelList.count < CHANNELONCELIST_MAX_NUMBER)
	{
		CHANNELtype* _pChn = (CHANNELtype*)mMalloc(sizeof(CHANNELtype));
		//	CHANNELtype* _pChn = (CHANNELtype*)malloc(sizeof(CHANNELtype));
		if(_pChn != NULL)
		{
			int _strlength;		
			_pChn->sdata[0] = CMD_START_CHAR_TX;			
			_pChn->sdata[1] = ACK_ID_CHAR;
			_pChn->sdata[2] = CMD_ACK;
			char _ack = (ack_a) ? '1' : '0';

			sprintf(&_pChn->sdata[3], "%c", _ack);
			_strlength = strlen(&_pChn->sdata[3]);
			_pChn->sdata_length = 8 + _strlength;
			CreatCRCToSend(&_pChn->sdata[0], 3 + _strlength);
			_pChn->sdata[7 + _strlength] = END_CHAR;
			ListInsertHead((PLIST)&USB_channelList, _pChn);			
		}
	}
}

//----------------------------
static bool prot_frame(char* pRecbuff, uint16_t length)
{			
	int ii;
	uint16_t _length = 0, _len;

	if (pRecbuff[0] != CMD_START_CHAR_RX)
	{
		return false;
	}

	if ((pRecbuff[1] != DIGITIN_ID_CHAR) && (pRecbuff[1] != ANALOG_ID_CHAR))
	{			
		return false;
	}
	
	if ((pRecbuff[2] != CMD_RESET) && (pRecbuff[2] != CMD_STAT)  && (pRecbuff[2] != CMD_RAW_DATA) && (pRecbuff[2] != CMD_EERD_F) && (pRecbuff[2] != CMD_EEWR_F) && (pRecbuff[2] != CMD_EERD_S) && (pRecbuff[2] != CMD_EEWR_S) && (pRecbuff[2] != CMD_ENC_PSET))
	{		
		return false;
	}

	for (ii = 0; ii < length; ii++)
	{
		if (pRecbuff[ii] == '\r')
		{					
			break;
		}
	}
	if (ii == length)
	{
		return false;
	}
	
/*	if ((pRecbuff[3] != CMD_RESET) && (pRecbuff[3] != CMD_STAT))
	{		
		return false;
	}*/
	
	_length = ii - 5;
	if (_length == 4)
	{
		unsigned short _CRC = 0;
		for (ii = 0; ii < _length; ii++)
		{
			_CRC = CRC16Algorithm(_CRC, pRecbuff[ii]);
		}
		char _ascii[4];
		uint16ToAscii(_CRC, _ascii);
		_len = length - 5;
		if ((pRecbuff[_len] |= _ascii[0]) || (pRecbuff[_len + 1] |= _ascii[1]) || (pRecbuff[_len + 2] |= _ascii[2]) || (pRecbuff[_len + 3] |= _ascii[3]))
		{
			// crc is bad
			return false;
		}
	}	
	return true;
}

//----------------------------
static bool protocol_parser(uint8_t* pRecbuff, uint32_t length)
{	
	if (prot_frame((char*)pRecbuff, length) == 1)
	{
		if (pRecbuff[2] == CMD_RESET)
		{
			// reset
		   SetTimerDec(RESET_FIRE, 1000);           // 1 sec
		   return true;
		}
		else
		if (pRecbuff[2] == CMD_STAT)
		{
			// utolso allapot
#if DIGIN			
			DigIn_force_sended();
			return true;
#endif			
		}
		else
		if ((pRecbuff[1] == ANALOG_ID_CHAR) && (pRecbuff[2] == CMD_RAW_DATA))
		{
			 // '$','A','d',CRC-16,'\r' - keri az analogtol a gaz, fek adc raw adatokat, es kormany
			AnaInRowData_force_sended();
		}
		else
		if ((pRecbuff[1] == ANALOG_ID_CHAR) && (pRecbuff[2] == CMD_ENC_PSET))
		{
			// '$','A','S',CRC-16,'\r' - Encoder SET commend
			Encoder_SET();
		}			
		else
		if (pRecbuff[2] == CMD_EERD_F)
		{ // eeprom rd float			
			char* _token0;
			//char* _token1 = NULL;
			float rddata = 0.0;
			bool _result = false;

			_token0 = strtok((char*)pRecbuff, ":");	
			_token0 =  strtok(NULL, ":");
			if (_token0 != NULL)
			{
				//_token1 =  strtok(_token0, ";"); 
			//	if (_token1 != NULL)
				//{
					int _ee_index =  atoi(_token0);   
					short _ee_address = EE_GetAddressFromArray(_ee_index);  
					if (_ee_address != -1)
					{						
						if (EE_ReadFloat(ONEEEaddr, &rddata, _ee_address))
						{
							if (USB_channelList.count < CHANNELONCELIST_MAX_NUMBER)
							{
								CHANNELtype* _pChn = (CHANNELtype*)mMalloc(sizeof(CHANNELtype));
								//	CHANNELtype* _pChn = (CHANNELtype*)malloc(sizeof(CHANNELtype));
								if(_pChn != NULL)
								{
									int _strlength;		
									_pChn->sdata[0] = CMD_START_CHAR_TX;			
									_pChn->sdata[1] = ANALOG_ID_CHAR;
									_pChn->sdata[2] = CMD_EERD_F;
									/*if (GazADCValue > 1000)
									{
										_strlength = 0;
				}*/
									sprintf(&_pChn->sdata[3], ":%d:%f:", _ee_index, rddata);
									_strlength = strlen(&_pChn->sdata[3]);
									_pChn->sdata_length = 8 + _strlength;
									CreatCRCToSend(&_pChn->sdata[0], 3 + _strlength);
									_pChn->sdata[7 + _strlength] = END_CHAR;
									ListInsertHead((PLIST)&USB_channelList, _pChn);	
									_result = true;
								}
							}						
						}
					}					
				//}
			}
			if (!_result)
			{							
				sendAckOrNotAck(false);				
			}			
			return _result;
		}
		else
		if (pRecbuff[2] == CMD_EERD_S)
		{ // eeprom rd short
			char* _token0;
			//char* _token1 = NULL;
			uint16_t rddata = 0;
			bool _result = false;

			_token0 = strtok((char*)pRecbuff, ":");	
			_token0 =  strtok(NULL, ":");

			if (_token0 != NULL)
			{
				//_token1 =  strtok(_token0, ":"); 
				//if (_token1 != NULL)
				//{
					int _ee_index =  atoi(_token0);   
					short _ee_address = EE_GetAddressFromArray(_ee_index);
					if (_ee_address != -1)
					{											
						if (EE_ReadUint16(ONEEEaddr, &rddata, _ee_address))
						{
							if (USB_channelList.count < CHANNELONCELIST_MAX_NUMBER)
							{
								CHANNELtype* _pChn = (CHANNELtype*)mMalloc(sizeof(CHANNELtype));
								//	CHANNELtype* _pChn = (CHANNELtype*)malloc(sizeof(CHANNELtype));
								if(_pChn != NULL)
								{
									int _strlength;		
									_pChn->sdata[0] = CMD_START_CHAR_TX;			
									_pChn->sdata[1] = ANALOG_ID_CHAR;
									_pChn->sdata[2] = CMD_EERD_S;
									/*if (GazADCValue > 1000)
									{
										_strlength = 0;
				}*/
									sprintf(&_pChn->sdata[3], ":%d:%d:", _ee_index, rddata);
									_strlength = strlen(&_pChn->sdata[3]);
									_pChn->sdata_length = 8 + _strlength;
									CreatCRCToSend(&_pChn->sdata[0], 3 + _strlength);
									_pChn->sdata[7 + _strlength] = END_CHAR;
									ListInsertHead((PLIST)&USB_channelList, _pChn);	
									_result = true;
								}
							}						
						}
					}
				//}
			}			
			if (!_result)
			{							
				sendAckOrNotAck(false);				
			}
			return _result;
		}	
		else
		if (pRecbuff[2] == CMD_EEWR_S)
		{ // eeprom wr short
			char* _token0;
			char* _token1 = NULL;
			//char* _token2 = NULL;
			uint16_t _sdata = 0;
			bool _result = false;
			
			_token0 = strtok((char*)pRecbuff, ":");	
			_token0 =  strtok(NULL, ":");
			if (_token0 != NULL)
			{
			//	_token1 =  strtok(_token0, ";"); 
			//	if (_token1 != NULL)
				//{
					int _ee_index =  atoi(_token0);   
					short _ee_address = EE_GetAddressFromArray(_ee_index);  
					if (_ee_address != -1)
					{						
						_token1 =  strtok(NULL, ":");
						//_token1 = strtok((char*)pRecbuff, ":");	
						if (_token1 != NULL)
						{							
							_sdata =  atoi(_token1);   															
							if (EE_WriteUint16(ONEEEaddr, _sdata, _ee_address))
							{ 
								_result = true;
							}
						}
					}					
				//}
			}									
			sendAckOrNotAck(_result);							
		    return true;
		}				
		if (pRecbuff[2] == CMD_EEWR_F)
		{ // eeprom wr float
			char* _token0;
			char* _token1 = NULL;	
		//	char* _token2 = NULL;
			bool _result = false;
			float _fdata = 0.0;
			
			_token0 = strtok((char*)pRecbuff, ":");	
			_token0 =  strtok(NULL, ":");
			if (_token0 != NULL)
			{
			//	_token1 =   strtok(NULL, ":"); 
				//if (_token1 != NULL)
				//{
					int _ee_index =  atoi(_token0);   
					short _ee_address = EE_GetAddressFromArray(_ee_index); 
					if (_ee_address != -1)
					{						
						_token1 =  strtok(NULL, ":");
						if (_token1 != NULL)
						{
							_fdata =  atof(_token1);   															
							if (EE_WriteFloat(ONEEEaddr, _fdata, _ee_address))
							{ 
								_result = true;
							}
						}
					}					
				//}				
			}			
			sendAckOrNotAck(_result);
		   return true;
		}		
	}
	return false;
}
//---------------------------
// public functions
//---------------------------

//----------------------------------
void Init_usb(void)
{
	ClearRxReady_usb();
	USBRxBufLen = 0;
	USBprevRxCount = 0;
	ListInit(&USB_channelList);
	tx_ready_timeout = false;
}

//----------------------------------
void USBH_exec()
{
	if (!IsConnected())
	{
		return;		
	}
	/*if (send((uint8_t*)"proba123456\n", 12) == USBD_OK)
		//	if (send((uint8_t*)USB_channel_current->sdata, USB_channel_current->sdata_length) == USBD_OK)
		{
		//	SetTimerDec(USB_TXD_READY, 100);
			//tx_ready_timeout = true;				
			Led2(true);
		}
	return;*/
	// TX part
	if (IsEndTimerDec(USB_TXD_TIMEOUT) == true)
	{ // 1500 ms
		Led3(true);
	}
	
	if (IsEndTimerDec(USB_TXD_READY) == true)
	{ // 30 ms
		if(CDC_IsTxReady() == USBD_OK)
		{
			Led3(false);
			tx_ready_timeout = false;	
			ClearTimerDec(USB_TXD_TIMEOUT);
			if (USB_channel_current != NULL)
			{
				mFree(USB_channel_current);
				//free(USB_channel_current);
			}
			USB_channel_current = NULL;
			if (IsTurnOn_led2() == true)
			{
				Led2(false);
			}
		}
		else
		{
			//SetTimerDec(USB_TXD_READY, 75);
		//	SetTimerDec(USB_TXD_READY, 30);
			SetTimerDec(USB_TXD_READY, 20);
			tx_ready_timeout = true;	
			Led3(true);
		}
	}
	if ((USB_channelList.count > 0) && (tx_ready_timeout == false))
	{			
		if (CDC_IsTxReady() == USBD_OK)
		{
			if (USB_channel_current == NULL)
			{							
				USB_channel_current = ListRemoveTail((PLIST)&USB_channelList);
			}
			if ((USB_channel_current != NULL) && (USB_channel_current->sdata[0] != 0) && (USB_channel_current->sdata_length > 0))
			{			
				SetTimerDec(USB_TXD_TIMEOUT, 2000);
				//if (send((uint8_t*)"proba123456\n", 12) == USBD_OK)
				if (send((uint8_t*)USB_channel_current->sdata, USB_channel_current->sdata_length) == USBD_OK)
				{
					//SetTimerDec(USB_TXD_READY, 75);
					SetTimerDec(USB_TXD_READY, 30);
					tx_ready_timeout = true;				
					Led2(true);
				}
			}
		}
	}		
	// RX part
	if (IsRxReady_usb() == 1)
	{
		if ((USBRxBufLen > CMD_MIN_LEN) && (USBRxBufLen <= USB_RX_DATA_SIZE))
		{
			Led2(true);
			if (!protocol_parser(USBRxBuffer, USBRxBufLen))
			{
				Led3(true);			
			}
		}
		ClearRxReady_usb();
		USBRxBufLen = 0;
		USBprevRxCount = 0;
	}
}	

//----------------------------------
void USBH_send(uint8_t* data, uint16_t size)
{
	if (!IsConnected())
	{
		return;		
	}
	send(data, size);
}
//----------------------------
/*void USBH_copyDataToTxBuffer(uint8_t* buffer, uint16_t len)
{
	if ((buffer != NULL) && (len > 0) && (len < 64))
	{			
		memcpy(tx_buffer, buffer, len);
		tx_length = len;		
	}
}*/