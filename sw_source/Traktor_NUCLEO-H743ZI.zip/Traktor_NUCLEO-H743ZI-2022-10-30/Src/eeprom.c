/*
 * eeprom.c
 *
 *  Created on 2019.06.27.
 *      Author: tiszai istvan
 */
//#include <stdio.h>
#include <string.h>
#include "defines.h"
#include "eeprom.h"
#include "eeprom_drv.h"
#include "helper.h"

static short EE_adr_array[EE_MAX_ADDRESS_ARRAY_INDEX];

bool EE_Init(void)
{     	
	if (EEPROM_Init() ==  EEPROM_FAIL)
	{
		return false;	
	}		
	EE_adr_array[0] = EE_VAIDATE;
	EE_adr_array[1] = EE_VERSION;
	EE_adr_array[2] = EE_GAZ_SZAZ_MAX;
	EE_adr_array[3] = EE_GAZ_ROW_MAX;
	EE_adr_array[4] = EE_GAZ_SZAZ_MIN;
	EE_adr_array[5] = EE_GAZ_ROW_MIN;
	EE_adr_array[6] = EE_FEK_MM_MAX;
	EE_adr_array[7] = EE_FEK_ROW_MAX;
	EE_adr_array[8] = EE_FEK_MM_MIN;
	EE_adr_array[9] = EE_FEK_ROW_MIN;
	EE_adr_array[10] = EE_KORMANY_FOK_MAX;
	EE_adr_array[11] = EE_KORMANY_IMP_MAX;
	EE_adr_array[12] = EE_KORMANY_FOK_MIN;
	EE_adr_array[13] = EE_KORMANY_IMP_MIN;
	EE_adr_array[14] = EE_END;
	return true;
}

//-----------------------------------------

short EE_GetAddressFromArray(short index)
{
	if ((index < 0) || (index >= EE_MAX_ADDRESS_ARRAY_INDEX))
	{
		return -1;			
	}
	return EE_adr_array[index];
}

//-----------------------------------------
bool EE_SetFirst(void)
{     	
#ifdef EEPROM
	uint8_t _rddata[2];
	uint8_t _wrdata[2];
	uint16_t _rdlen = 2;
	uint16_t _wrVersion;
	uint16_t _rdVersion;
				
	_wrdata[0] = 0x55;
	_wrdata[1] = 0xAA;
	if (!EE_WriteBin(ONEEEaddr, _wrdata, EE_VAIDATE, 2))
		return false;
	if (!EE_ReadBin(ONEEEaddr, _rddata, EE_VAIDATE, &_rdlen))
		return false;
	if ((_rddata[0] != 0x55) || (_rddata[1] != 0xAA))
		return false;
	// version	
	_wrVersion = (uint16_t)VERSION;
	if (!EE_WriteUint16(ONEEEaddr, _wrVersion, EE_VERSION))
		return false;	
	if(!EE_ReadUint16(ONEEEaddr, &_rdVersion, EE_VERSION))	
		return false;	
	if ((_wrVersion != _rdVersion))
		return false;
#endif	
	return true;
}

//-----------------------------------------
bool EE_IsEmpty(void)
{     	
#ifdef EEPROM
	uint8_t rddata[2];
	uint16_t _rdlen = 2;
				
	if (!EE_ReadBin(ONEEEaddr, rddata, EE_VAIDATE, &_rdlen) )
		//EE_WriteUint16(EEDEVICEADDRESS EEAddress, uint16_t wrdata, uint16_t wraddr)
		return false;
	//if ((rddata[0] != 0x55) || (rddata[1] != 0xAA))
	if (rddata[1] != 0xAA)
		return false;
#endif		
	return true;
}

//-----------------------------------------
bool EE_WriteString(EEDEVICEADDRESS EEAddress, const char* datastr, uint16_t wraddr)
{
	uint16_t DevAddress = EEPROM_I2C_ADDRESS_A01_W;
/*	if (EEAddress == TWOEEaddr)
		DevAddress = EEPROM_I2C_ADDRESS_A02_W;*/
	bool _result = true;
#ifdef EEPROM		
	if (datastr == NULL) 
		return false;
	uint16_t _len = strlen(datastr);
	if (_len > 32) 
		return false;		
	if (EEPROM_WriteBuffer(DevAddress, (uint8_t*)datastr, wraddr, _len) == EEPROM_FAIL)
	{
		_result = false;
	}
#endif	
	return _result;
}

//-----------------------------------------
bool EE_WriteBin(EEDEVICEADDRESS EEAddress, uint8_t* wrdata, uint16_t wraddr, uint16_t len)
{
	uint16_t DevAddress = EEPROM_I2C_ADDRESS_A01_W;
/*	if (EEAddress == TWOEEaddr)
		DevAddress = EEPROM_I2C_ADDRESS_A02_W;*/
	bool _result = true;
#ifdef EEPROM		
	if (wrdata == NULL) 
		return false;
	if (len > 128) 
		return false;		
	if (EEPROM_WriteBuffer(DevAddress, wrdata, wraddr, len) == EEPROM_FAIL)
	{
		_result = false;
	}
#endif	
	return _result;
}

//-----------------------------------------
bool EE_ReadBin(EEDEVICEADDRESS EEAddress, uint8_t* rddata, uint16_t rdaddr, uint16_t* len)
{
	uint16_t DevAddress = EEPROM_I2C_ADDRESS_A01_R;
/*	if (EEAddress == TWOEEaddr)
		DevAddress = EEPROM_I2C_ADDRESS_A02_R;*/
	bool _result = true;
#ifdef EEPROM		
	if ((rddata == NULL) || (len == NULL))
		return false;		
	if (EEPROM_ReadBuffer(DevAddress, rddata, rdaddr, len)  == EEPROM_FAIL)
	{
		_result = false;
	}
#endif	
	return _result;
}

//-----------------------------------------
bool EE_WriteUint16(EEDEVICEADDRESS EEAddress, uint16_t wrdata, uint16_t wraddr)
{
	uint16_t DevAddress = EEPROM_I2C_ADDRESS_A01_W;
/*	if (EEAddress == TWOEEaddr)
		DevAddress = EEPROM_I2C_ADDRESS_A02_W;*/
	bool _result = true;
#ifdef EEPROM		
	_result = EE_WriteBin(EEAddress, (uint8_t*)&wrdata, wraddr, 2);
	if (_result)
	{
		HAL_Delay(1);
		uint8_t _crcwr = genCRC8bits((uint8_t*)&wrdata, 2);
		_result = EE_WriteBin(EEAddress, &_crcwr, wraddr + 2, 1);
		if (_result)
		{					
			HAL_Delay(1);
			uint16_t _rddata;			
			_result = EE_ReadUint16(EEAddress, &_rddata, wraddr);
			if (_result)
			{							
				if (_rddata != wrdata)
				{
					_result = false; 
					;
				}				
			}
		}		
	}
#endif	
	return _result;
}

//-----------------------------------------
bool EE_ReadUint16(EEDEVICEADDRESS EEAddress, uint16_t* rddata, uint16_t rdaddr)
{
	uint16_t DevAddress = EEPROM_I2C_ADDRESS_A01_R;
	/*if (EEAddress == TWOEEaddr)
		DevAddress = EEPROM_I2C_ADDRESS_A02_R;*/
	bool _result = true;	
#ifdef EEPROM		
	uint16_t _len = 2;
	_result = EE_ReadBin(EEAddress, (uint8_t*)rddata, rdaddr, &_len);
	if (_result)
	{							
		_len = 1;
		uint8_t _crcrd = genCRC8bits((uint8_t*)rddata, 2);
		uint8_t _crcrde; 
		_result = EE_ReadBin(EEAddress, &_crcrde, rdaddr + 2, &_len);
		if (_result)
		{									
			if (_crcrde != _crcrd)
			{							
				_result = false;
			}
		}
	}	
#endif	
	HAL_Delay(1);
	return _result;
}

//-----------------------------------------
bool EE_WriteUint32(EEDEVICEADDRESS EEAddress, uint32_t wrdata, uint16_t wraddr)
{	
	uint16_t DevAddress = EEPROM_I2C_ADDRESS_A01_W;
	/*if (EEAddress == TWOEEaddr)
		DevAddress = EEPROM_I2C_ADDRESS_A02_W;*/
	bool _result = true;
#ifdef EEPROM		
	_result = EE_WriteBin(DevAddress, (uint8_t*)&wrdata, wraddr, 4);
	if (_result)
	{
		HAL_Delay(1);
		uint8_t _crcwr = genCRC8bits((uint8_t*)&wrdata, 4);
		_result = EE_WriteBin(DevAddress, &_crcwr, wraddr + 4, 1);
		if (_result)
		{					
			HAL_Delay(1);
			uint32_t _rddata;			
			_result = EE_ReadUint32(DevAddress, &_rddata, wraddr);
			if (_result)
			{							
				if (_rddata != wrdata)
				{
					_result = false;
				}				
			}
		}		
	}
#endif	
	HAL_Delay(1);
	return _result;
}

//-----------------------------------------
bool EE_ReadUint32(EEDEVICEADDRESS EEAddress, uint32_t* rddata, uint16_t rdaddr)
{
	uint16_t DevAddress = EEPROM_I2C_ADDRESS_A01_R;
/*	if (EEAddress == TWOEEaddr)
		DevAddress = EEPROM_I2C_ADDRESS_A02_R;*/
	bool _result = true;	
#ifdef EEPROM		
	uint16_t _len = 4;
	_result = EE_ReadBin(DevAddress, (uint8_t*)rddata, rdaddr, &_len);
	if (_result)
	{							
		_len = 1;
		uint8_t _crcrd = genCRC8bits((uint8_t*)rddata, 4);
		uint8_t _crcrde; 
		_result = EE_ReadBin(DevAddress, &_crcrde, rdaddr + 4, &_len);
		if (_result)
		{									
			if (_crcrde != _crcrd)
			{							
				_result = false;
			}
		}
	}	
#endif	
	HAL_Delay(1);
	return _result;
}

//-----------------------------------------
bool EE_WriteFloat(EEDEVICEADDRESS EEAddress, float wrdata, uint16_t wraddr)
{
	uint16_t DevAddress = EEPROM_I2C_ADDRESS_A01_W;
/*	if (EEAddress == TWOEEaddr)
		DevAddress = EEPROM_I2C_ADDRESS_A02_W;*/
	bool _result = true;
#ifdef EEPROM		
	_result = EE_WriteBin(DevAddress, (uint8_t*)&wrdata, wraddr, 4);
	if (_result)
	{
		HAL_Delay(1);
		uint8_t _crcwr = genCRC8bits((uint8_t*)&wrdata, 4);
		_result = EE_WriteBin(DevAddress, &_crcwr, wraddr + 4, 1);
		if (_result)
		{					
			HAL_Delay(1);
			float _rddata;			
			_result = EE_ReadFloat(DevAddress, &_rddata, wraddr);
			if (_result)
			{							
				if (_rddata != wrdata)
				{
					_result = false;
				}				
			}
		}		
	}
#endif	
	HAL_Delay(1);
	return _result;	
}

//-----------------------------------------
bool EE_ReadFloat(EEDEVICEADDRESS EEAddress, float* rddata, uint16_t rdaddr)
{
	uint16_t DevAddress = EEPROM_I2C_ADDRESS_A01_R;
	/*if (EEAddress == TWOEEaddr)
		DevAddress = EEPROM_I2C_ADDRESS_A02_R;*/
	bool _result = true;	
#ifdef EEPROM		
	uint16_t _len = 4;
	_result = EE_ReadBin(DevAddress, (uint8_t*)rddata, rdaddr, &_len);
	if (_result)
	{							
		_len = 1;
		uint8_t _crcrd = genCRC8bits((uint8_t*)rddata, 4);
		uint8_t _crcrde; 
		_result = EE_ReadBin(DevAddress, &_crcrde, rdaddr + 4, &_len);
		if (_result)
		{									
			if (_crcrde != _crcrd)
			{							
				_result = false;
			}	
		}
	}	
#endif	
	HAL_Delay(1);
	return _result;	
}

//-----------------------------------------
//	Test 
//-----------------------------------------
//-----------------------------------------
bool EE_test()
{
	if (eE_test(ONEEEaddr))
	{
		return true;
		/*if (eE_test(TWOEEaddr) == false)
		{
			return false;
		}*/
	}	
	return true;
}

//-----------------------------------------
bool eE_test(EEDEVICEADDRESS EEAddress)
{
#ifdef EEPROM	
	uint16_t _wrlen = 0;
	uint8_t wrdata[128];
	uint8_t rddata[128];
	uint16_t _rdlen = 2;
	
	wrdata[0] = 0x55;
	wrdata[1] = 0xaa;
	
	if (EE_WriteBin(EEAddress, &wrdata[0], 0, 2) == false)
		return false;
	if (EE_ReadBin(EEAddress, rddata, 0, &_rdlen) == false)
		return false;
	if ((rddata[0] != wrdata[0]) || (rddata[1] != wrdata[1]))
		return false;
			
	_wrlen = strlen("VA0001");
	strncpy((char*)wrdata, "VA0001", _wrlen);
	if (EE_WriteString(EEAddress, "VA0001", 100) == false)
		return false;
		
	_rdlen = 32;
	if (EE_ReadBin(EEAddress, rddata, 100, &_rdlen) == false)
		return false;
	int ii;
	for (ii = 0; ii < _wrlen; ii++)
	{
		if (wrdata[ii] != rddata[ii])
		{
			return false;
		}
	}		
	for (ii = 0; ii < 128; ii++)
	{
		wrdata[ii] = ii;
	}
	if (EE_WriteBin(EEAddress, wrdata, 128, 128) == false)
		return false;
	_rdlen = 128;
	if (EE_ReadBin(EEAddress, rddata, 128, &_rdlen) == false)
		return false;
	for (ii = 0; ii < 128; ii++)
	{
		if (wrdata[ii] != rddata[ii])
		{
			return false;
		}
	}		
	if (EE_WriteUint16(EEAddress, 61234, 256)  == false)
		return false;
	uint16_t rduint16 = 0;
	if (EE_ReadUint16(EEAddress, &rduint16, 256) == false)
		return false;
	if (rduint16 != 61234)
		return false;
	
	if (EE_WriteUint32(EEAddress, 4294967294, 550)  == false)
		return false;
	uint32_t rduint32 = 0;
	if (EE_ReadUint32(EEAddress, &rduint32, 550) == false)
		return false;
	if (rduint32 != 4294967294)
		return false;	
	
	if (EE_WriteFloat(EEAddress, 128.25, 600)  == false)
		return false;
	float rdfloat = 0;
	if (EE_ReadFloat(EEAddress, &rdfloat, 600) == false)
		return false;
	if (rdfloat != 128.25)
		return false;	
	return true;
#endif	
}

