/*
 * leds.c
 *
 *  Created: 2020.06.22. 
 *  Author: tiszai
 */ 
#include "defines.h"
#include "main.h"
#include "leds.h"
// private variables
// private declarations

//----------------------------
// private functions
//----------------------------

//----------------------------
// public functions
//----------------------------

void Led1(bool on)
{ // green
	if (on)			
	{			
		HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, GPIO_PIN_SET);
	}
	else	
	{			
		HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, GPIO_PIN_RESET);
	}
}

//----------------------------
bool IsTurnOn_led1(void)
{
	if (HAL_GPIO_ReadPin(LD1_GPIO_Port, LD1_Pin) == GPIO_PIN_SET)
	{
		return true;
	}
	return false;
}

//----------------------------
void Led2(bool on)
{ // blue
	if (on)			
	{			
		HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_SET);
	}
	else	
	{			
		HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);
	}
}

//----------------------------
bool IsTurnOn_led2(void)
{
	if (HAL_GPIO_ReadPin(LD2_GPIO_Port, LD2_Pin) == GPIO_PIN_SET)
	{
		return true;
	}
	return false;
}

//----------------------------
void Led3(bool on)
{
	 // red
	if(on)			
	{			
		HAL_GPIO_WritePin(LD3_GPIO_Port, LD3_Pin, GPIO_PIN_SET);
	}
	else	
	{			
		HAL_GPIO_WritePin(LD3_GPIO_Port, LD3_Pin, GPIO_PIN_RESET);
	}
}

//----------------------------
bool IsTurnOn_led3(void)
{
	if (HAL_GPIO_ReadPin(LD3_GPIO_Port, LD3_Pin) == GPIO_PIN_SET)
	{
		return true;
	}
	return false;
}

//----------------------------
void LedsBlink(int delay, int count)
{
	int ii = 0;
	int _count = 0;
	while (1)
	{			
		switch (ii)
		{			
		case 0:
			Led1(true);
			Led2(true);
			Led3(true);
			break;
		case 1:
			Led1(true);
			Led2(false);
			Led3(true);
			break;
		case 2:
			Led1(true);
			Led2(true);
			Led3(false);
			break;	
		case 3:
			Led1(true);
			Led2(false);
			Led3(true);
			break;	
		case 4:
			Led1(false);
			Led2(true);
			Led3(true);
			break;	
		case 5:
			Led1(false);
			Led2(false);
			Led3(false);
			if (count >= 0)
			{
				_count++;
				if (_count >= count)
				{
					return;				
				}
			}
			break;			
		}
		ii = (ii == 5) ? 0 :++ ii;	
		HAL_Delay(delay); 
	}
}

//----------------------------
void Test(bool on)
{
	// test pin
	if(on)			
	{			
		HAL_GPIO_WritePin(TEST_GPIO_Port, TEST_Pin, GPIO_PIN_SET);
	}
	else	
	{			
		HAL_GPIO_WritePin(TEST_GPIO_Port, TEST_Pin, GPIO_PIN_RESET);
	}
}

//----------------------------
void TestToggle(void)
{
	// test toggle
	if(HAL_GPIO_ReadPin(TEST_GPIO_Port, TEST_Pin) == GPIO_PIN_SET)
	{
		HAL_GPIO_WritePin(TEST_GPIO_Port, TEST_Pin, GPIO_PIN_RESET);
	}
	else
	{
		HAL_GPIO_WritePin(TEST_GPIO_Port, TEST_Pin, GPIO_PIN_SET);
	}	
}

//----------------------------
void Test1(bool on)
{
	// test pin
	if(on)			
	{			
		HAL_GPIO_WritePin(TEST1_GPIO_Port, TEST1_Pin, GPIO_PIN_SET);
	}
	else	
	{			
		HAL_GPIO_WritePin(TEST1_GPIO_Port, TEST1_Pin, GPIO_PIN_RESET);
	}
}

//----------------------------
void Test1Toggle(void)
{
	// test toggle
	if(HAL_GPIO_ReadPin(TEST1_GPIO_Port, TEST1_Pin) == GPIO_PIN_SET)
	{
		HAL_GPIO_WritePin(TEST1_GPIO_Port, TEST1_Pin, GPIO_PIN_RESET);
	}
	else
	{
		HAL_GPIO_WritePin(TEST1_GPIO_Port, TEST1_Pin, GPIO_PIN_SET);
	}	
}