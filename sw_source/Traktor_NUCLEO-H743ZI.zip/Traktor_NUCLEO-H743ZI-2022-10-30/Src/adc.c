/**
  ******************************************************************************
  * File Name          : ADC.c
  * Description        : This file provides code for the configuration
  *                      of the ADC instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "adc.h"

/* USER CODE BEGIN 0 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "defines.h"
#include "myMallocFree.h"
#include "usbd_process.h"
#include "list.h"
#include "leds.h"
#include "helper.h"
#include "stm32h7xx_it.h"	
#include "eeprom.h"


// 84 ms, 128 db
#define ADC_CONVERTED_DATA_BUFFER_SIZE   ((uint32_t)  128)   /* Size of array aADCxConvertedData[] */
//volatile ALIGN_32BYTES(static uint16_t   aADCxConvertedData[ADC_CONVERTED_DATA_BUFFER_SIZE]);
volatile  DMA_ADC_BUFFER uint16_t   aADC1ConvertedData[ADC_CONVERTED_DATA_BUFFER_SIZE];
volatile  DMA_ADC_BUFFER uint16_t   aADC2ConvertedData[ADC_CONVERTED_DATA_BUFFER_SIZE];
ALIGN_32BYTES(static uint16_t   aDC1Buffer[ADC_CONVERTED_DATA_BUFFER_SIZE]);
ALIGN_32BYTES(static uint16_t   aDC2Buffer[ADC_CONVERTED_DATA_BUFFER_SIZE]);
static int gazADCFlag = -1; 
uint16_t GazADCValue = 0;
uint16_t GazADCValue_prev = 0;
#define GAZ_MIN_ROW_VALUE  0 //0 NEM VEGLEGES, eeprombol
#define GAZ_MAX_ROW_VALUE  3103 //4096 * (2.5V/3.3V), NEM VEGLEGES, eeprombol
#define GAZ_WEIGHTED_THRESHOLD  100

#define FEK_MIN_ROW_VALUE  0 //0 NEM VEGLEGES, eeprombol
#define FEK_MAX_ROW_VALUE  3103 //4096 * (2.5V/3.3V), NEM VEGLEGES, eeprombol
#define FEK_WEIGHTED_THRESHOLD  100

static int fekADCFlag = -1; 
uint16_t FekADCValue = 0;
uint16_t FekADCValue_prev = 0;
WEIGHTED_ADC_RAW gaz_weighted_average;
WEIGHTED_ADC_RAW fek_weighted_average;
extern LIST USB_channelList;
extern int16_t EncoderDegrea;
extern uint16_t Encoder_last_data;
#if TEST_ANAL_NO_EXPENDED
extern RNG_HandleTypeDef hrng;
__IO uint8_t    ubUserButtonClickEvent;
static uint32_t aRandom32bit[8];
#endif
//void AnaIn_force_sended(void);
/* USER CODE END 0 */

ADC_HandleTypeDef hadc1;
ADC_HandleTypeDef hadc2;
DMA_HandleTypeDef hdma_adc1;
DMA_HandleTypeDef hdma_adc2;

/* ADC1 init function */
void MX_ADC1_Init(void)
{
  ADC_MultiModeTypeDef multimode = {0};
  ADC_ChannelConfTypeDef sConfig = {0};

  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV256;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ConversionDataManagement = ADC_CONVERSIONDATA_DMA_CIRCULAR;
  hadc1.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
  hadc1.Init.LeftBitShift = ADC_LEFTBITSHIFT_NONE;
  hadc1.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure the ADC multi-mode
  */
  multimode.Mode = ADC_MODE_INDEPENDENT;
  if (HAL_ADCEx_MultiModeConfigChannel(&hadc1, &multimode) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_7;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_387CYCLES_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  sConfig.OffsetSignedSaturation = DISABLE;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

}
/* ADC2 init function */
void MX_ADC2_Init(void)
{
  ADC_ChannelConfTypeDef sConfig = {0};

  /** Common config
  */
  hadc2.Instance = ADC2;
  hadc2.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV256;
  hadc2.Init.Resolution = ADC_RESOLUTION_12B;
  hadc2.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc2.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc2.Init.LowPowerAutoWait = DISABLE;
  hadc2.Init.ContinuousConvMode = ENABLE;
  hadc2.Init.NbrOfConversion = 1;
  hadc2.Init.DiscontinuousConvMode = DISABLE;
  hadc2.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc2.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc2.Init.ConversionDataManagement = ADC_CONVERSIONDATA_DMA_CIRCULAR;
  hadc2.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
  hadc2.Init.LeftBitShift = ADC_LEFTBITSHIFT_NONE;
  hadc2.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc2) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_8;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  sConfig.OffsetSignedSaturation = DISABLE;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

}

static uint32_t HAL_RCC_ADC12_CLK_ENABLED=0;

void HAL_ADC_MspInit(ADC_HandleTypeDef* adcHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(adcHandle->Instance==ADC1)
  {
  /* USER CODE BEGIN ADC1_MspInit 0 */

  /* USER CODE END ADC1_MspInit 0 */
    /* ADC1 clock enable */
    HAL_RCC_ADC12_CLK_ENABLED++;
    if(HAL_RCC_ADC12_CLK_ENABLED==1){
      __HAL_RCC_ADC12_CLK_ENABLE();
    }

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**ADC1 GPIO Configuration
    PA7     ------> ADC1_INP7
    */
    GPIO_InitStruct.Pin = GPIO_PIN_7;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* ADC1 DMA Init */
    /* ADC1 Init */
    hdma_adc1.Instance = DMA1_Stream0;
    hdma_adc1.Init.Request = DMA_REQUEST_ADC1;
    hdma_adc1.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_adc1.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_adc1.Init.MemInc = DMA_MINC_ENABLE;
    hdma_adc1.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    hdma_adc1.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    hdma_adc1.Init.Mode = DMA_CIRCULAR;
    hdma_adc1.Init.Priority = DMA_PRIORITY_MEDIUM;
    hdma_adc1.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    if (HAL_DMA_Init(&hdma_adc1) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(adcHandle,DMA_Handle,hdma_adc1);

  /* USER CODE BEGIN ADC1_MspInit 1 */
  /* USER CODE END ADC1_MspInit 1 */
  }
  else if(adcHandle->Instance==ADC2)
  {
  /* USER CODE BEGIN ADC2_MspInit 0 */

  /* USER CODE END ADC2_MspInit 0 */
    /* ADC2 clock enable */
    HAL_RCC_ADC12_CLK_ENABLED++;
    if(HAL_RCC_ADC12_CLK_ENABLED==1){
      __HAL_RCC_ADC12_CLK_ENABLE();
    }

    __HAL_RCC_GPIOC_CLK_ENABLE();
    /**ADC2 GPIO Configuration
    PC5     ------> ADC2_INP8
    */
    GPIO_InitStruct.Pin = GPIO_PIN_5;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    /* ADC2 DMA Init */
    /* ADC2 Init */
    hdma_adc2.Instance = DMA1_Stream1;
    hdma_adc2.Init.Request = DMA_REQUEST_ADC2;
    hdma_adc2.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_adc2.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_adc2.Init.MemInc = DMA_MINC_ENABLE;
    hdma_adc2.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    hdma_adc2.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    hdma_adc2.Init.Mode = DMA_CIRCULAR;
    hdma_adc2.Init.Priority = DMA_PRIORITY_MEDIUM;
    hdma_adc2.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    if (HAL_DMA_Init(&hdma_adc2) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(adcHandle,DMA_Handle,hdma_adc2);

  /* USER CODE BEGIN ADC2_MspInit 1 */

  /* USER CODE END ADC2_MspInit 1 */
  }
}

void HAL_ADC_MspDeInit(ADC_HandleTypeDef* adcHandle)
{

  if(adcHandle->Instance==ADC1)
  {
  /* USER CODE BEGIN ADC1_MspDeInit 0 */

  /* USER CODE END ADC1_MspDeInit 0 */
    /* Peripheral clock disable */
    HAL_RCC_ADC12_CLK_ENABLED--;
    if(HAL_RCC_ADC12_CLK_ENABLED==0){
      __HAL_RCC_ADC12_CLK_DISABLE();
    }

    /**ADC1 GPIO Configuration
    PA7     ------> ADC1_INP7
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_7);

    /* ADC1 DMA DeInit */
    HAL_DMA_DeInit(adcHandle->DMA_Handle);
  /* USER CODE BEGIN ADC1_MspDeInit 1 */

  /* USER CODE END ADC1_MspDeInit 1 */
  }
  else if(adcHandle->Instance==ADC2)
  {
  /* USER CODE BEGIN ADC2_MspDeInit 0 */

  /* USER CODE END ADC2_MspDeInit 0 */
    /* Peripheral clock disable */
    HAL_RCC_ADC12_CLK_ENABLED--;
    if(HAL_RCC_ADC12_CLK_ENABLED==0){
      __HAL_RCC_ADC12_CLK_DISABLE();
    }

    /**ADC2 GPIO Configuration
    PC5     ------> ADC2_INP8
    */
    HAL_GPIO_DeInit(GPIOC, GPIO_PIN_5);

    /* ADC2 DMA DeInit */
    HAL_DMA_DeInit(adcHandle->DMA_Handle);
  /* USER CODE BEGIN ADC2_MspDeInit 1 */

  /* USER CODE END ADC2_MspDeInit 1 */
  }
}

/* USER CODE BEGIN 1 */
bool ADC1_Calibration(void)
{
	if (HAL_ADCEx_Calibration_Start(&hadc1, ADC_CALIB_OFFSET, ADC_SINGLE_ENDED) != HAL_OK)
	{
		return false;
	}
	return true;
}

bool ADC1_Start(void)
{
	if (HAL_ADC_Start_DMA(&hadc1, (uint32_t *)aADC1ConvertedData, ADC_CONVERTED_DATA_BUFFER_SIZE) != HAL_OK)
	{
		return false;
	}
	return true;
}

bool ADC2_Calibration(void)
{
	if (HAL_ADCEx_Calibration_Start(&hadc2, ADC_CALIB_OFFSET, ADC_SINGLE_ENDED) != HAL_OK)
	{
		return false;
	}
	return true;
}

bool ADC2_Start(void)
{
	if (HAL_ADC_Start_DMA(&hadc2, (uint32_t *)aADC2ConvertedData, ADC_CONVERTED_DATA_BUFFER_SIZE) != HAL_OK)
	{
		return false;
	}
	return true;
}

/**
  * @brief  Conversion complete callback in non-blocking mode
  * @param  hadc: ADC handle
  * @retval None
  */
void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef* hadc)
{
	/* Invalidate Data Cache to get the updated content of the SRAM on the first half of the ADC converted data buffer: 64 bytes */
	if (hadc == &hadc1)
	{			
		SCB_InvalidateDCache_by_Addr((uint32_t *) &aADC1ConvertedData[0], ADC_CONVERTED_DATA_BUFFER_SIZE);	
	}
	else
	if (hadc == &hadc2)
	{			
		SCB_InvalidateDCache_by_Addr((uint32_t *) &aADC2ConvertedData[0], ADC_CONVERTED_DATA_BUFFER_SIZE);	
	}
}

/**
  * @brief  Conversion DMA half-transfer callback in non-blocking mode
  * @param  hadc: ADC handle
  * @retval None
  */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
	/* Invalidate Data Cache to get the updated content of the SRAM on the second half of the ADC converted data buffer: 64 bytes */
	if (hadc == &hadc1)
	{			
		SCB_InvalidateDCache_by_Addr((uint32_t *) &aADC1ConvertedData[ADC_CONVERTED_DATA_BUFFER_SIZE / 2], ADC_CONVERTED_DATA_BUFFER_SIZE);   // 84 ms, 128 db
		memcpy(&aDC1Buffer[0], &aADC1ConvertedData[0], ADC_CONVERTED_DATA_BUFFER_SIZE * 2);
		gazADCFlag = (gazADCFlag == -1) ? 1 : 2;
	}
	else
	if (hadc == &hadc2)
	{			
		SCB_InvalidateDCache_by_Addr((uint32_t *) &aADC2ConvertedData[ADC_CONVERTED_DATA_BUFFER_SIZE / 2], ADC_CONVERTED_DATA_BUFFER_SIZE);  // 84 ms, 128 db
		memcpy(&aDC2Buffer[0], &aADC2ConvertedData[0], ADC_CONVERTED_DATA_BUFFER_SIZE * 2);
		fekADCFlag = (fekADCFlag == -1) ? 1 : 2;
	}		
	/*if (aADCxConvertedData[50] > 1000)
	{
		return;
	}*/
	//Test1Toggle();
}

/**
  * @brief  ADC error callback in non blocking mode
  *        (ADC conversion with interruption or transfer by DMA)
  * @param  hadc: ADC handle
  * @retval None
  */
void HAL_ADC_ErrorCallback(ADC_HandleTypeDef *hadc)
{
	/* In case of ADC error, call main error handler */
	Error_Handler();
}

#ifdef ADC_WEIGHTED_AVERAGE
//----------------------------------------------------------
//----------------------------------------------------------
uint16_t  GetGazRotationMedianWeightedAvg(uint16_t data_avg, bool start)
{
	if(start == 1)
	{
		gaz_weighted_average.OneMinusY = 0.5f;
		gaz_weighted_average.Y = 0.5f;
		gaz_weighted_average.filtered_value_prev = data_avg;              
		gaz_weighted_average.thresold = GAZ_WEIGHTED_THRESHOLD;
	}
	if (abs(gaz_weighted_average.filtered_value_prev - data_avg) > gaz_weighted_average.thresold)
	{
		if (gaz_weighted_average.Y < 0.98f)
		{					
			gaz_weighted_average.Y += 0.01f;
		}
	}
	else
	if (abs(gaz_weighted_average.filtered_value_prev - data_avg) < gaz_weighted_average.thresold)
	{
		if (gaz_weighted_average.Y > 0.02f)
		{					
			gaz_weighted_average.Y -= 0.01f;
		}
	}
	gaz_weighted_average.OneMinusY = 1.0f - gaz_weighted_average.Y;
	gaz_weighted_average.filtered_value_prev = gaz_weighted_average.filtered_value_prev * gaz_weighted_average.OneMinusY + data_avg * gaz_weighted_average.Y;
            
	return (uint16_t)gaz_weighted_average.filtered_value_prev;
}

//----------------------------------------------------------
uint16_t  GetFekRotationMedianWeightedAvg(uint16_t data_avg, bool start)
{
	if (start == 1)
	{
		fek_weighted_average.OneMinusY = 0.5f;
		fek_weighted_average.Y = 0.5f;
		fek_weighted_average.filtered_value_prev = data_avg;              
		fek_weighted_average.thresold = FEK_WEIGHTED_THRESHOLD;
	}
	if (abs(fek_weighted_average.filtered_value_prev - data_avg) > fek_weighted_average.thresold)
	{
		if (fek_weighted_average.Y < 0.98f)
		{					
			fek_weighted_average.Y += 0.01f;
		}
	}
	else
	if (abs(fek_weighted_average.filtered_value_prev - data_avg) < fek_weighted_average.thresold)
	{
		if (fek_weighted_average.Y > 0.02f)
		{					
			fek_weighted_average.Y -= 0.01f;
		}
	}
	fek_weighted_average.OneMinusY = 1.0f - fek_weighted_average.Y;
	fek_weighted_average.filtered_value_prev = fek_weighted_average.filtered_value_prev * fek_weighted_average.OneMinusY + data_avg * fek_weighted_average.Y;
            
	return (uint16_t)fek_weighted_average.filtered_value_prev;
}
#endif
//----------------------------------
// Gaz pedal part
//----------------------------------
/*void AnaInGaz_force_sended(void)
{
	if (USB_channelList.count < CHANNELONCELIST_MAX_NUMBER)
	{
		CHANNELtype* _pChn = (CHANNELtype*)mMalloc(sizeof(CHANNELtype));
		//	CHANNELtype* _pChn = (CHANNELtype*)malloc(sizeof(CHANNELtype));
		if(_pChn != NULL)
		{
			int _strlength;		
			_pChn->sdata[0] = CMD_START_CHAR_TX;			
			_pChn->sdata[1] = ANALOG_ID_CHAR;
			_pChn->sdata[2] = ANALOG_GAZ_CHAR;
			sprintf(&_pChn->sdata[3], "%hu", GazADCValue);
			_strlength = strlen(&_pChn->sdata[3]);
			_pChn->sdata_length = 8 + _strlength;
			CreatCRCToSend(&_pChn->sdata[0], 3 + _strlength);
			_pChn->sdata[7 + _strlength] = END_CHAR;
			ListInsertHead((PLIST)&USB_channelList, _pChn);			
		}
	}
}*/

//---------------------------------------
void Gaz_Adc_processing(void)
{
	//uint32_t _sum_temp = 0;
	//uint32_t _sum_row_data = 0;
	//bool _sendToUsb = false;
	if (gazADCFlag > 0)
	{
		uint32_t _sum_temp = 0;
		uint32_t _sum_row_data = 0;
		bool _sendToUsb = false;
		for (int ii = 0; ii < ADC_CONVERTED_DATA_BUFFER_SIZE; ii++)
		{
			_sum_temp += aDC1Buffer[ii];
		}
		_sum_row_data  = _sum_temp / (ADC_CONVERTED_DATA_BUFFER_SIZE);		

		if (gazADCFlag == 1)
		{
			 // start
			GazADCValue =  GetGazRotationMedianWeightedAvg(_sum_row_data, true);		
		}
		else
		if (gazADCFlag == 2)
		{
			GazADCValue =  GetGazRotationMedianWeightedAvg(_sum_row_data, false);
		}
		gazADCFlag = 0;
	//	GazADCValue = _sum_row_data;
		if (GazADCValue > GazADCValue_prev) 
		{
			if (abs(GazADCValue - GazADCValue_prev) > GAZ_WEIGHTED_THRESHOLD)
			{
				_sendToUsb = true;
			}
		}
		else
		if (GazADCValue < GazADCValue_prev) 			
		{
			if (abs(GazADCValue_prev - GazADCValue) > GAZ_WEIGHTED_THRESHOLD)
			{
				_sendToUsb = true;
			}
		}
		//GazADCValue_prev = GazADCValue;
		if (_sendToUsb)	
		{
	/*		if (_sum_row_data > 1000)
			{
				_sum_row_data = 0;
			}*/
			//AnaInGaz_force_sended();
			AnaIn_force_sended();			
			GazADCValue_prev = GazADCValue;
		}	
/*		else
		{
			if (IsEndTimerDec(ANALIN_SEND_TIME) == true)
			{
				SetTimerDec(ANALIN_SEND_TIME, 1500);
				//AnaInGaz_force_sended();
				AnaIn_force_sended();
			}			
		}*/
	}
}	

//----------------------------------
// Fek pedal part
//----------------------------------
/*void AnaInFek_force_sended(void)
{
	if (USB_channelList.count < CHANNELONCELIST_MAX_NUMBER)
	{
		CHANNELtype* _pChn = (CHANNELtype*)mMalloc(sizeof(CHANNELtype));
		//	CHANNELtype* _pChn = (CHANNELtype*)malloc(sizeof(CHANNELtype));
		if(_pChn != NULL)
		{
			int _strlength;		
			_pChn->sdata[0] = CMD_START_CHAR_TX;			
			_pChn->sdata[1] = ANALOG_ID_CHAR;
			_pChn->sdata[2] = ANALOG_FEK_CHAR;
			
			sprintf(&_pChn->sdata[3], "%hu", FekADCValue);
			_strlength = strlen(&_pChn->sdata[3]);
			_pChn->sdata_length = 8 + _strlength;
			CreatCRCToSend(&_pChn->sdata[0], 3 + _strlength);
			_pChn->sdata[7 + _strlength] = END_CHAR;
			ListInsertHead((PLIST)&USB_channelList, _pChn);			
		}
	}
}*/

//---------------------------------------
void Fek_Adc_processing(void)
{
	//uint32_t _sum_temp = 0;
	//uint32_t _sum_row_data = 0;
	//bool _sendToUsb = false;
	if(fekADCFlag > 0)
	{
		uint32_t _sum_temp = 0;
		uint32_t _sum_row_data = 0;
		bool _sendToUsb = false;
		for (int ii = 0; ii < ADC_CONVERTED_DATA_BUFFER_SIZE; ii++)
		{
			_sum_temp += aDC2Buffer[ii];
		}
		_sum_row_data  = _sum_temp / (ADC_CONVERTED_DATA_BUFFER_SIZE);		

		if (fekADCFlag == 1)
		{
			// start
		   FekADCValue =  GetFekRotationMedianWeightedAvg(_sum_row_data, true);		
		}
		else
		if (fekADCFlag == 2)
		{
			FekADCValue =  GetFekRotationMedianWeightedAvg(_sum_row_data, false);
		}
		fekADCFlag = 0;
		
		if(FekADCValue > FekADCValue_prev) 
		{
			if (abs(FekADCValue - FekADCValue_prev) > FEK_WEIGHTED_THRESHOLD)
			{
				_sendToUsb = true;
			}
		}
		else
		if(FekADCValue < FekADCValue_prev) 			
		{
			if (abs(FekADCValue_prev - FekADCValue) > FEK_WEIGHTED_THRESHOLD)
			{
				_sendToUsb = true;
			}
		}
		if(_sendToUsb)	
		{		
			AnaIn_force_sended();
			FekADCValue_prev = FekADCValue;
// TEST start 2021-08-19	
		//	EncoderDegrea = FekADCValue;
	/*		
			CHANNELtype* _pChn = (CHANNELtype*)mMalloc(sizeof(CHANNELtype));
			sprintf(&_pChn->sdata[0], ":%hu:%hu:", FekADCValue, EncoderDegrea);			
			int _strlength = strlen(&_pChn->sdata[0]);
			_pChn->sdata_length = _strlength;		
			ListInsertHead((PLIST)&USB_channelList, _pChn);*/
// TEST end	2021-08-19	

		}	
	/*	else
		{
			if (IsEndTimerDec(ANALIN_SEND_TIME) == true)
			{
				SetTimerDec(ANALIN_SEND_TIME, 1500);
				//AnaInFek_force_sended();
				AnaIn_force_sended();
			}			
		}*/
	}
}	


//----------------------------------------------
void AnaIn_force_sended(void)
{
	if (USB_channelList.count < CHANNELONCELIST_MAX_NUMBER)
	{
		CHANNELtype* _pChn = (CHANNELtype*)mMalloc(sizeof(CHANNELtype));
		//	CHANNELtype* _pChn = (CHANNELtype*)malloc(sizeof(CHANNELtype));
		if (_pChn != NULL)
		{
			int _strlength;	
			uint16_t rddata = 1;
			int _gazSpeed = 0;
			int _gazEEMax = 1; 
			int	_gazEEMin = 1;
			int _gazEEMaxRow = 1; 
			int _gazEEMinRow = 1;
			int _fekMoving = 0;
			int _fekEEMax = 1; 
			int _fekEEMin = 1;
			int _fekEEMaxRow = 1; 
			int _fekEEMinRow = 1;		
			
			_pChn->sdata[0] = CMD_START_CHAR_TX;			
			_pChn->sdata[1] = ANALOG_ID_CHAR;
			_pChn->sdata[2] = ANALOG_FEK_GAZ_CHAR;
			/*if (GazADCValue > 1000)
			{
				_strlength = 0;
			}*/
			// gaz
			if (EE_ReadUint16(ONEEEaddr, &rddata, EE_GetAddressFromArray(2)))
			{				
				_gazEEMax = rddata;
			}
			else
			{
				_gazEEMax = 1;
			}
			if (EE_ReadUint16(ONEEEaddr, &rddata, EE_GetAddressFromArray(3)))
			{				
				_gazEEMaxRow = rddata;
			}
			else
			{
				_gazEEMaxRow = 1;
			}	
			if (EE_ReadUint16(ONEEEaddr, &rddata, EE_GetAddressFromArray(4)))
			{				
				_gazEEMin = rddata;
			}
			else
			{
				_gazEEMin = 1;
			}	
			if (EE_ReadUint16(ONEEEaddr, &rddata, EE_GetAddressFromArray(5)))
			{				
				_gazEEMinRow = rddata;
			}
			else
			{
				_gazEEMinRow = 0;
			}			
			float _div = (float)(_gazEEMaxRow - _gazEEMinRow);			
			_div = (_div <= 0) ? 1 : _div; 
			float _speedDive  = (float)(_gazEEMax - _gazEEMin);
			_speedDive  = (_speedDive  <= 0) ? 1 : _speedDive; 
			if (_div == 0)
			{
				_div = 1.0;
			}	
			_gazSpeed = (int)(((float)(GazADCValue - _gazEEMinRow) / _div) * (_speedDive));
			if (_gazSpeed < 0)
			{
				_gazSpeed = 0;				
			}
			
			// fek
			if (EE_ReadUint16(ONEEEaddr, &rddata, EE_GetAddressFromArray(6)))
			{				
				_fekEEMax = rddata;
			}
			else
			{
				_fekEEMax = 1;
			}
			if (EE_ReadUint16(ONEEEaddr, &rddata, EE_GetAddressFromArray(7)))
			{				
				_fekEEMaxRow = rddata;
			}
			else
			{
				_fekEEMaxRow = 1;
			}	
			if (EE_ReadUint16(ONEEEaddr, &rddata, EE_GetAddressFromArray(8)))
			{				
				_fekEEMin = rddata;
			}
			else
			{
				_fekEEMin = 1;
			}	
			if (EE_ReadUint16(ONEEEaddr, &rddata, EE_GetAddressFromArray(9)))
			{				
				_fekEEMinRow = rddata;
			}
			else
			{
				_fekEEMinRow = 1;
			}			
			_fekEEMaxRow = 1400;
			_fekEEMinRow = 460;			
			
			_div = (float)(_fekEEMaxRow - _fekEEMinRow);			
			_div = (_div <= 0) ? 1 : _div; 
			_fekEEMax = 100; 
			//_fekEEMax = 80; 
			_fekEEMin = 0;
			float _fekDive  = (float)(_fekEEMax - _fekEEMin);
			_fekDive  = (_fekDive  <= 0) ? 1 : _fekDive; 
			if (_div == 0)
			{
				_div = 1.0;
			}				
			_fekMoving = (int)(((float)(FekADCValue - _fekEEMinRow) / _div) * (_fekDive));	
			_fekMoving = 100 - _fekMoving;
			if (_fekMoving < 0)
			{
				_fekMoving = 0;				
			}
#if			TEST_ANAL_NO_EXPENDED
			if (ubUserButtonClickEvent == SET)
			{
				for (int ii = 0; ii < 8; ii++)
				{
					if (HAL_RNG_GenerateRandomNumber(&hrng, &aRandom32bit[ii]) != HAL_OK)
					{
						/* Random number generation error */
						Error_Handler();      
					}
				}
				ubUserButtonClickEvent = RESET;
				_gazSpeed = (int)(100.0 * (aRandom32bit[0] / 4294967295.0));
				_fekMoving = (int)(100.0 * (aRandom32bit[1] / 4294967295.0));
				Encoder_last_data = aRandom32bit[2];
			}
			else
			{
				//65535
				_gazSpeed = (int)(100.0 * (aRandom32bit[3] / 4294967295.0));
				_fekMoving = (int)(100.0 * (aRandom32bit[4] / 4294967295.0));
				Encoder_last_data = aRandom32bit[5];
			}			
#endif			
			//sprintf(&_pChn->sdata[3], ":%3d:%hu:%3d:%hu:%3d:", _gazSpeed, GazADCValue, _fekMoving, FekADCValue, EncoderDegrea);	
			sprintf(&_pChn->sdata[3], ":%3d:%hu:%3d:%hu:%5d:", _gazSpeed, GazADCValue, _fekMoving, FekADCValue, EncoderDegrea);
			
			//	sprintf(&_pChn->sdata[3], ":%3d:%hu:%3d:%hu:%3d:%3d:", _gazSpeed, GazADCValue, _fekMoving, FekADCValue, Encoder_last_data, EncoderDegrea);
			//	EncoderDegrea = 0;
			_strlength = strlen(&_pChn->sdata[3]);
			_pChn->sdata_length = 8 + _strlength;
			CreatCRCToSend(&_pChn->sdata[0], 3 + _strlength);
			_pChn->sdata[7 + _strlength] = END_CHAR;
			ListInsertHead((PLIST)&USB_channelList, _pChn);			
		}
	}
	else
		return;
}

//----------------------------------------------
void AnaInRowData_force_sended(void)
{
	if (USB_channelList.count < CHANNELONCELIST_MAX_NUMBER)
	{
		CHANNELtype* _pChn = (CHANNELtype*)mMalloc(sizeof(CHANNELtype));
		//	CHANNELtype* _pChn = (CHANNELtype*)malloc(sizeof(CHANNELtype));
		if(_pChn != NULL)
		{
			int _strlength;		
			_pChn->sdata[0] = CMD_START_CHAR_TX;			
			_pChn->sdata[1] = ANALOG_ID_CHAR;
			_pChn->sdata[2] = CMD_RAW_DATA;
			sprintf(&_pChn->sdata[3], ":%4d:%4d:", GazADCValue, FekADCValue);
			_strlength = strlen(&_pChn->sdata[3]);
			_pChn->sdata_length = 8 + _strlength;
			CreatCRCToSend(&_pChn->sdata[0], 3 + _strlength);
			_pChn->sdata[7 + _strlength] = END_CHAR;
			ListInsertHead((PLIST)&USB_channelList, _pChn);			
		}
	}
}
/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
