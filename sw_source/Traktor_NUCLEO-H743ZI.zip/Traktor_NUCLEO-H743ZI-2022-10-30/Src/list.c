/***************************************************************************
 *    general list queue.
 *    modul name: list.c
 *    author:         Tiszai Istvan.
 *    Environment: kernel & user
 * $Log: list.cpp,v $
 * Revision 1.2  2003/10/10 17:57:01  Tiszai Isvan
 *
 ***************************************************************************/

#include <stdlib.h>
#include "list.h"
#include "myMallocFree.h"

//static short _list_count;

/****************************************************************************
 * 
 ****************************************************************************/

int ListInit( PLIST list )
{
	if (list==NULL)
		return FALSE;
	list->head  = NULL;
	list->tail  = NULL;
	list->block = NULL;
	list->count = 0;
	return TRUE;
}/* BOOLEAN ListInit( PLIST list ) */

/****************************************************************************
 * 
 ****************************************************************************/
int ListClear( PLIST list )
{
	PLIST tml, tmplist = list;

	list->count = 0;
	if (list == NULL)
		return FALSE;

	while (tmplist->tail != NULL)
		tmplist = tmplist->tail;

	if (tmplist->head == NULL)
	{
		return TRUE;
	}

	while( tmplist->head != NULL )
	{
		if (tmplist->block != NULL)
		{
			mFree(tmplist->block);
			//ExFreePool(tmplist->block);
		}			
		tml = tmplist->head;
		mFree(tmplist);
		//	ExFreePool( tmplist );
		tmplist=tml;
	}
    list->head=NULL;
    list->block=NULL;
    list->tail=NULL;
	return TRUE;
}/* BOOLEAN ListClear( PLIST list, KSPIN_LOCK* lock ) */

/****************************************************************************
 * 
 ****************************************************************************/
int ListInsertTail( PLIST list, void* data )
{
	PLIST newlist, tmplist;

	if (list==NULL && data==NULL)
		return FALSE;

	//newlist = (PLIST)EXAllocatePool( sizeof(LIST));
	newlist = (PLIST)mMalloc(sizeof(LIST));
	if (newlist == NULL)
		return FALSE;
	
	newlist->block = data;
	newlist->tail  = NULL;

	tmplist = list;

	while ( tmplist->tail != NULL  )
		tmplist=tmplist->tail; 

	newlist->head = tmplist;
	tmplist->tail = newlist;
	list->count++;
	return TRUE;
}/* BOOLEAN ListInstertTail( PLIST list, VOID* block ) */

/****************************************************************************
 * 
 ****************************************************************************/
void* ListRemoveTail( PLIST list )
{
	PLIST tmplist;
	void* data = NULL;
	if (list==NULL)
		return NULL;
	tmplist = list;

	while( tmplist->tail != NULL )
		tmplist=tmplist->tail;

    if (tmplist->head != NULL)
    {
	    (tmplist->head)->tail=NULL;
	    data = tmplist->block;
	  //  ExFreePool( tmplist );
	    mFree(tmplist);
    }
	list->count--;
	return data; 
}/* VOID* ListRemoveTail( PLIST list, KSPIN_LOCK* lock) */

/****************************************************************************
 * 
 ****************************************************************************/
int ListInsertHead( PLIST list, void* data )
{
	PLIST newlist;

	if (list==NULL && data==NULL)
		return FALSE;

	//newlist = (PLIST)EXAllocatePool( sizeof(LIST) );
	newlist = (PLIST)mMalloc(sizeof(LIST));
	if (newlist == NULL)
		return FALSE;

	newlist->block = data;
	newlist->head  = list;
	if (list->tail != NULL)
	{
		newlist->tail  = list->tail;
		(list->tail)->head=newlist;
	}
	else
		newlist->tail  = NULL;

	list->tail = newlist;
	list->count++;
	return TRUE;

}/* BOOLEAN ListInstertHead( PLIST list, VOID* block, KSPIN_LOCK* lock ) */

/****************************************************************************
 * 
 ****************************************************************************/
void* ListRemoveHead( PLIST list )
{
	PLIST tmplist;
	void* data = NULL;

	if (list==NULL)
		return NULL;

	tmplist = list->tail;

	if (tmplist != NULL)
	{
		data = tmplist->block;
		list->tail = tmplist->tail;
        if (tmplist->tail != NULL)
            (tmplist->tail)->head=list;
		//ExFreePool( tmplist );
		  mFree(tmplist);
	}
	list->count--;
	return data;
}/* VOID* ListRemoveHead( PLIST list, KSPIN_LOCK* lock ) */


/****************************************************************************
 * 
 ****************************************************************************/
short ListGetCount(PLIST list)
{
	return list->count;
}