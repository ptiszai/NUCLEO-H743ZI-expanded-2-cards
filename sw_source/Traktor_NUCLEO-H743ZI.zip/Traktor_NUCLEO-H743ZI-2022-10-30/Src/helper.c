/*
 * helper.c
 *
 *  Created on: 2020.06.20.
 *      Author: tiszai istvan
 */

#include <stdlib.h>  
#include <string.h> 
#include <stdint.h>
#include "defines.h"
#include "stm32h7xx_hal.h"
#include "helper.h"

/**************************************************************************
    Function: strLength(const char* data);                                             
  **************************************************************************/
int strLength(const char* data)
{
    if (*data == 0)
        return 0;
    int count = 0;
	while (*data++ != 0) 
    {
        count++;
    } 
    return count;
}

/***************************************************************************
    Function: void hextoascii(char ch, char* ascii)                                            
  **************************************************************************/
void hextoascii(char ch, char* ascii)
{
    char c0 = ch >> 4;
    if (c0 > 0x09)
       ascii[0] =  c0 + 55;
    else
       ascii[0] =  c0 + '0';      
    c0 = ch & 0x0F;
    if (c0 > 0x09)
       ascii[1] =  c0 + 55;
    else
       ascii[1] =  c0 + '0';  
}

#if 0
/***************************************************************************
    Function: void hex2ascii(char ch, char* ascii)                                            
  **************************************************************************/
void hex2ascii(uint16_t myInt, char* buf)
{ //buf: 5 length array
    // example: 25 -> buf[0] = 0x30, buf[1] = 0x30, buf[2] = 0x32, buf[3] = 0x35, buf[4] = 0
    sprintf(buf, "%04u", myInt);	
}

/***************************************************************************
    Function:  uint16_t HexArrayTouint16(uint8_t pwH, uint8_t pwL)                                           
  **************************************************************************/
uint16_t HexArrayTouint16(uint8_t pwH, uint8_t pwL)
{
  char hight = asciitohex(pwH);
  char low = asciitohex(pwL);
  return  (low + (hight * 10));
}
#endif

/***************************************************************************
    Function: char asciitohex(char ch)                                              
  **************************************************************************/
char asciitohex(char ch) 
{
    if (ch>'9')
        ch+=9;
    ch&=0x0F;
    return ch;
}

/***************************************************************************
    Function: uint16_t  uint16ToAsciiuint16(uint16_t src)                                            
  **************************************************************************/
unsigned char hex[16] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
void uint16ToAscii(uint16_t src, char* ascii)
{ 
	ascii[0] = hex[src / 4096];
	ascii[1] = hex[(src / 256) % 16];
	ascii[2] = hex[(src % 256) / 16];
	ascii[3] = hex[(src % 256) % 16];      
} 

/***************************************************************************
    Function: uint16_t  uint16ToAsciiuint16(uint16_t src)                                            
  **************************************************************************/
uint16_t  uint16ToAsciiuint16(uint16_t src)
{ 
    char buf[2];
    hextoascii(src, buf);  
    uint16_t _result = (uint16_t)buf[1];      
    _result += (((uint16_t)buf[0]) << 8);
    return _result;
} 

/***************************************************************************
    Function: uint16_t  asciiuint16Touint16(uint16_t src)                                           
  **************************************************************************/
uint16_t  asciiuint16Touint16(uint16_t src)
{ 
    char buf[2];
    uint16_t _result;
    buf[0] = (uint8_t)src;
    buf[1] = (uint8_t)(src >>8);
    char hight = asciitohex(buf[1]);
    char low   = asciitohex(buf[0]);  
    _result =  low + (hight * 16);   
    return _result;
} 

#if 0
/***************************************************************************
    Function:
                                             
  **************************************************************************/
void uint32TOuint8Array(uint32_t* src, uint8_t* dest)
{
    *dest++ = (*src) & 0x000000ff;
    *dest++   = (*src) >> 4;
    *dest++   = (*src) >> 8;
    *dest++   = (*src) >> 16;
}
#endif

/**************************************************************************
    The used standard is: CRC-CCITT (CRC-16)                                            
  *************************************************************************/
unsigned short CRC16Algorithm(uint16_t crc, uint8_t Ch)
{
	unsigned int _genPoly = 0x1021;  //CCITT CRC-16 Polynominal
	unsigned int _uiCharShifted = ((unsigned int)Ch & 0x00FF) << 8;
	crc = crc ^ _uiCharShifted;
	for (int ii = 0; ii < 8; ii++)
	{
		if (crc & 0x8000)
			crc = (crc << 1) ^ _genPoly;
		else
			crc = crc << 1;
	}
	crc &= 0xFFFF;
	return crc;
}

/**************************************************************************
    The used standard is: CRC-CCITT (CRC-8)                                            
  *************************************************************************/
uint8_t genCRC8bits(uint8_t *data, uint16_t len)
{
	uint8_t crc = 0xff;
	uint16_t i, j;
	for (i = 0; i < len; i++) 
	{
		crc ^= data[i];
		for (j = 0; j < 8; j++) 
		{
			if ((crc & 0x80) != 0)
				crc = (uint8_t)((crc << 1) ^ 0x31);
			else
				crc <<= 1;
		}
	}
	return crc;
}

//----------------------------
bool CreatCRCToSend(char* crcBuffer, int len)
{
	if (crcBuffer != NULL)
	{		
		unsigned short _CRC = 0;		
		for (int ii = 0; ii < len; ii++)
		{
			_CRC = CRC16Algorithm(_CRC, crcBuffer[ii]);
		}
		char _ascii[4];
		uint16ToAscii(_CRC, _ascii);
		crcBuffer[len++] = _ascii[0];
		crcBuffer[len++] = _ascii[1];
		crcBuffer[len++] = _ascii[2];
		crcBuffer[len++] = _ascii[3];		
		return true;
	}
	return false;
}


/*-----------------------------------------------------------------------*/
/* String functions                                                      */
/*-----------------------------------------------------------------------*/

/* Copy memory to memory */

void mem_cpy(void* dst, const void* src, uint32_t cnt) 
{
	uint8_t *d = (uint8_t*)dst;
	const uint8_t *s = (const uint8_t*)src;

	if (cnt)
	{
		do 
		{
			*d++ = *s++;
		} 
		while (--cnt);
	}
}

/* Fill memory block */
void mem_set(void* dst, int val, uint32_t cnt) 
{
	uint8_t *d = (uint8_t*)dst;

	do 
	{
		*d++ = (uint8_t)val;
	} 
	while (--cnt);
}

/* Compare memory block */
int mem_cmp(const void* dst, const void* src, uint32_t cnt) 
{
	/* ZR:same, NZ:different */
	const uint8_t *d = (const uint8_t *)dst, *s = (const uint8_t *)src;
	int r = 0;

	do 
	{
		r = *d++ -*s++;
	} 
	while (--cnt && r == 0);

	return r;
}