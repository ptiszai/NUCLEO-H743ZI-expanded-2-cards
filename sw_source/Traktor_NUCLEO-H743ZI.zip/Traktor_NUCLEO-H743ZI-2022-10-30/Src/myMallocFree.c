/*
 * myMallocFree.c
 *
 *  Created: 2020.06.24. 
 *  Author: tiszai
 */ 
// https://barrgroup.com/embedded-systems/how-to/detecting-memory-leaks-c
#include <stdlib.h>
#include <string.h>
#include "defines.h"
#include "myMallocFree.h"

// private variables
static BlockEntry blocks[MNUM_BLOCKS];
static long FS_totalAllocated = 0;

//----------------------------
// private functions
//----------------------------
static int getBlockNumber(void)
{
	int ii;
	for (ii = 0; ii < MNUM_BLOCKS; ii++)
	{
		if (blocks[ii].address == NULL)
		{
			break;
		}
	}
	return ii;
}

//----------------------------
// public functions
//----------------------------
//----------------------------
void *mMalloc(size_t size)
{
	int ii;
			
	if (getBlockNumber() > MNUM_BLOCKS)
	{
		return NULL;
	}
	void *newAllocation = malloc(size);

	for (ii = 0; ii < MNUM_BLOCKS; ii++)
	{
		if (blocks[ii].address == NULL)
		{
			// found empty entry; use it 
			blocks[ii].address = newAllocation;
			blocks[ii].size = size;
			//incrementCountForSize(size);
			break;
		}
	}

	FS_totalAllocated += size;
	return newAllocation;
}

//----------------------------
void mFree(void *blockToFree)
{
	int ii;

	for (ii = 0; ii < MNUM_BLOCKS; ii++)
	{
		if (blocks[ii].address == blockToFree)
		{
			// found block being released 
			//decrementCountForSize(blocks[i].size);
			FS_totalAllocated -= blocks[ii].size;
			blocks[ii].address = 0;
			blocks[ii].size = 0;
			break;
		}
	}
	free(blockToFree);
}
/*void mDisplayTable(void)
{
	printf("%s", "\nSize\tFreq.");
	for (int i = 0; i < NUM_SIZES; i++)
	{
		if (counters[i].size == 0) break;
		printf("\n%d\t\t%d", counters[i].size, counters[i].count);
	}
}*/

//----------------------------
void mClearTable(void)
{
	for (int ii = 0; ii < MNUM_BLOCKS; ii++)
	{
		if (blocks[ii].address == NULL)
		{
			free(blocks[ii].address);
			blocks[ii].address = NULL;
			blocks[ii].size = 0;						
		}
	}
	FS_totalAllocated = 0;
}