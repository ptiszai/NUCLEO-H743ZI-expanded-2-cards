/*
 * digitInput.c
 *
 *  Created: 2020.06.23. 
 *  Author: tiszai
 */ 

//#include <stdlib.h>
//#include <string.h>
#include "myMallocFree.h"
#include "defines.h"
#include "digitInput.h"
#include "stm32h7xx_it.h"
#include "main.h"
#include "usbd_process.h"
#include "helper.h"
#include "list.h"
#if DIGIN
// private variables
// private declarations
// extern variables
#if TEST_DIGIN_NO_EXPENDED
extern RNG_HandleTypeDef hrng;
__IO uint8_t    ubUserButtonClickEvent;
static uint32_t aRandom32bit[8];
#endif
extern LIST USB_channelList;
static DIGITIN digIn;

//----------------------------
// private functions
//----------------------------
void read_DIINx(void)
{
#if			TEST_DIGIN_NO_EXPENDED

	if (ubUserButtonClickEvent == SET)
	{
		int ii;
		for (ii = 0; ii < 16; ii++)
		{										
			digIn.din[ii] = '1';			
		}
		for (ii = 0; ii < 8; ii++)
		{
			if (HAL_RNG_GenerateRandomNumber(&hrng, &aRandom32bit[ii]) != HAL_OK)
			{
				/* Random number generation error */
				Error_Handler();      
			}
		}
		int _index = 0;
		for (ii = 0; ii < 8; ii++)
		{
			_index = aRandom32bit[ii] % 16;
			if (_index < 15)
			{				
				digIn.din[_index] = '0';
			}
		}
		ubUserButtonClickEvent = RESET;		
	}
#else
	digIn.din[0] = (HAL_GPIO_ReadPin(DIIN0_GPIO_Port, DIIN0_Pin) == GPIO_PIN_SET) ? '1' : '0';
	digIn.din[1] = (HAL_GPIO_ReadPin(DIIN1_GPIO_Port, DIIN1_Pin) == GPIO_PIN_SET) ? '1' : '0';
	digIn.din[2] = (HAL_GPIO_ReadPin(DIIN2_GPIO_Port, DIIN2_Pin) == GPIO_PIN_SET) ? '1' : '0';
	digIn.din[3] = (HAL_GPIO_ReadPin(DIIN3_GPIO_Port, DIIN3_Pin) == GPIO_PIN_SET) ? '1' : '0';
	digIn.din[4] = (HAL_GPIO_ReadPin(DIIN4_GPIO_Port, DIIN4_Pin) == GPIO_PIN_SET) ? '1' : '0';
	digIn.din[5] = (HAL_GPIO_ReadPin(DIIN5_GPIO_Port, DIIN5_Pin) == GPIO_PIN_SET) ? '1' : '0';
	digIn.din[6] = (HAL_GPIO_ReadPin(DIIN6_GPIO_Port, DIIN6_Pin) == GPIO_PIN_SET) ? '1' : '0';
	digIn.din[7] = (HAL_GPIO_ReadPin(DIIN7_GPIO_Port, DIIN7_Pin) == GPIO_PIN_SET) ? '1' : '0';
	digIn.din[8] = (HAL_GPIO_ReadPin(DIIN8_GPIO_Port, DIIN8_Pin) == GPIO_PIN_SET) ? '1' : '0';
	digIn.din[9] = (HAL_GPIO_ReadPin(DIIN9_GPIO_Port, DIIN9_Pin) == GPIO_PIN_SET) ? '1' : '0';
	digIn.din[10] = (HAL_GPIO_ReadPin(DIIN10_GPIO_Port, DIIN10_Pin) == GPIO_PIN_SET) ? '1' : '0';
	digIn.din[11] = (HAL_GPIO_ReadPin(DIIN11_GPIO_Port, DIIN11_Pin) == GPIO_PIN_SET) ? '1' : '0';
	digIn.din[12] = (HAL_GPIO_ReadPin(DIIN12_GPIO_Port, DIIN12_Pin) == GPIO_PIN_SET) ? '1' : '0';
	digIn.din[13] = (HAL_GPIO_ReadPin(DIIN13_GPIO_Port, DIIN13_Pin) == GPIO_PIN_SET) ? '1' : '0';
	digIn.din[14] = (HAL_GPIO_ReadPin(DIIN14_GPIO_Port, DIIN14_Pin) == GPIO_PIN_SET) ? '1' : '0';
	digIn.din[15] = (HAL_GPIO_ReadPin(DIIN15_GPIO_Port, DIIN15_Pin) == GPIO_PIN_SET) ? '1' : '0';
	digIn.din[16] = (HAL_GPIO_ReadPin(Tamper_GPIO_Port, Tamper_Pin) == GPIO_PIN_SET) ? '1' : '0';	
#endif

}
//----------------------------
// public functions
//----------------------------

//----------------------------------
void Init_digIn(void)
{
	digIn.status = '0';
	digIn.status_prev = '0';
	for (int ii; ii < DIGITIN_LENGTH; ii++)
	{
		digIn.din[ii] = '0';
		digIn.din_prev[ii] = '0';
	}	
	SetTimerDec(DIGIN_READ_TIME, 100);
}

//----------------------------------
void DigIn_force_sended(void)
{
	if (USB_channelList.count < CHANNELONCELIST_MAX_NUMBER)
	{
		CHANNELtype* _pChn = (CHANNELtype*)mMalloc(sizeof(CHANNELtype));
		//	CHANNELtype* _pChn = (CHANNELtype*)malloc(sizeof(CHANNELtype));
			if(_pChn != NULL)
		{
			_pChn->sdata_length = 8 + DIGITIN_LENGTH;
			_pChn->sdata[0] = CMD_START_CHAR_TX;
			//	_pChn->sdata[1] = CMD_START_CHAR_TX;
				_pChn->sdata[1] = DIGITIN_ID_CHAR;
			_pChn->sdata[2] = digIn.status;
			for (int ii = 0; ii < DIGITIN_LENGTH; ii++)
			{
				_pChn->sdata[3 + ii] = digIn.din[ii];
			}
			CreatCRCToSend(&_pChn->sdata[0], 3 + DIGITIN_LENGTH);
			_pChn->sdata[7 + DIGITIN_LENGTH] = END_CHAR;
			ListInsertHead((PLIST)&USB_channelList, _pChn);
			digIn.change = false;
		}
	}
}

//----------------------------------
void DigIn_exec(void)
{
	if (IsEndTimerDec(DIGIN_READ_TIME) == true)
	{ // 100 ms
		read_DIINx();
	
		if (digIn.status != digIn.status_prev)
		{
			digIn.change = true;
			digIn.status_prev = digIn.status;
		}
		for (int ii = 0 ; ii < DIGITIN_LENGTH; ii++)
		{
			if (digIn.din[ii] != digIn.din_prev[ii])
			{
				digIn.change = true;
				digIn.din_prev[ii] = digIn.din[ii];
			}
		}
		if (digIn.change)
		{
			DigIn_force_sended();
		/*	CHANNELtype* _pChn = (CHANNELtype*)mMalloc(sizeof(CHANNELtype));
		//	CHANNELtype* _pChn = (CHANNELtype*)malloc(sizeof(CHANNELtype));
			if (_pChn != NULL)
			{
				_pChn->sdata_length = 8 + DIGITIN_LENGTH;
				_pChn->sdata[0] = CMD_START_CHAR_TX;
			//	_pChn->sdata[1] = CMD_START_CHAR_TX;
				_pChn->sdata[1] = DIGITIN_ID_CHAR;
				_pChn->sdata[2] = digIn.status;
				for (int ii=0; ii < DIGITIN_LENGTH; ii++)
				{
					_pChn->sdata[3 + ii] = digIn.din[ii];
				}
				CreatCRCToSend(&_pChn->sdata[0], 3 + DIGITIN_LENGTH);
				_pChn->sdata[7 + DIGITIN_LENGTH] = END_CHAR;
				ListInsertHead((PLIST)&USB_channelList, _pChn);
				digIn.change = false;
			}*/
		}
		SetTimerDec(DIGIN_READ_TIME, 100);
	}
}
#endif

//----------------------------------
char TamberButton_read(void)
{
	return (HAL_GPIO_ReadPin(Tamper_GPIO_Port, Tamper_Pin) == GPIO_PIN_SET) ? '1' : '0';
}
