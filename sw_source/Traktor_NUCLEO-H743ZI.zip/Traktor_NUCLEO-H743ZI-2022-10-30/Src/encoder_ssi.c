/*
 * Encoder: encoder_ssi.c
 *
 *  Created: 2021.01.23. 
 *  Author: tiszai
 *  SICK ARS60-AAA32767
 *  Absolute Encoder Singleturn ARS 60 SSI and Parallel, blind hollow shaft
 *  Singleturn
 *  Resolution: up to 15 bits (32,768 increments)
 *  Electrical interface: SSI with gray code type or gray capped
 *  Zero-set function HIGH (12 V), 100 ms
 *  CW (clockwise), left, right, HIGH right (if not connected).
 *  communication: SICK_kommunication1.png
 *  bekotes: SICK_bekotes.png
 *  product_information_ars60_absolute_encoders_singleturn._modular_design_for_tailor_made_solutions_en_im0038486.pdf
 */
//#define TEST = 1
#include <stdlib.h>
#include <stdio.h>
#include "stm32h7xx_hal.h"
#include "stm32h7xx_it.h"
#include "spi.h"
#include "main.h"
#include "defines.h"
#include "encoder_ssi.h"
#include "helper.h"
#include "usbd_process.h"
#include "list.h"
#include "myMallocFree.h"
#include "adc.h"
#undef STEERINGTEST
#ifdef STEERINGTEST
kkk
#define LIMITDEGREES 2.0f // fok
//#define DIVISORPERDEGREES 2048.0f
#define DIVISORPERDEGREES 32767.5
bool flag = true;
static int32_t raw = 0;
#else
#define LIMITDEGREES 2.0f
#define DIVISORPERDEGREES 32767.5
#endif


// public variables

uint16_t EncoderDegrea = 0;
//int Ei_plus = 0;
// extern variables
extern LIST USB_channelList;
// private variables

extern uint16_t FekADCValue;
// private variables
static uint8_t rdata_prev[4];
//uint16_t encoderOffset = 10242;

uint16_t Encoder_last_data = 0;
//uint16_t encoder_remain_data = 0;
static uint16_t encoder_prev_data = 0;
//static bool ei_prev_plus = false;
static int32_t diffRaw = 0;
//static int ei_plus = 0;
// private functions
//----------------------------
/*static HAL_StatusTypeDef encoder_tx_send(uint8_t* data, uint16_t size)
{
	// HAL_StatusTypeDef 
	return  HAL_SPI_Transmit(&hspi4, data, size, 10);  // HAL_TIMEOUT, HAL_ERROR, HAL_OK
}*/

//----------------------------
static HAL_StatusTypeDef encoder_rx_receive(uint8_t* data, uint16_t size)
{
	// HAL_StatusTypeDef 
	return  HAL_SPI_Receive(&hspi4, data, size, 10);   // HAL_TIMEOUT, HAL_ERROR, HAL_OK
}

//----------------------------
static uint binaryToGray(uint num)
{
	return num ^ (num >> 1); // The operator >> is shift right. The operator ^ is exclusive or.
}

//----------------------------
uint grayToBinary32(uint num)
{
	num ^= num >> 16;
	num ^= num >>  8;
	num ^= num >>  4;
	num ^= num >>  2;
	num ^= num >>  1;
	return num;
}

//----------------------------
// public functions
//----------------------------
//----------------------------
void Encoder_SET(void)
{
	HAL_GPIO_WritePin(PRES_GPIO_Port, PRES_Pin, GPIO_PIN_RESET);
	HAL_Delay(50);
	HAL_GPIO_WritePin(PRES_GPIO_Port, PRES_Pin, GPIO_PIN_SET);
	HAL_Delay(2000); 
	HAL_GPIO_WritePin(PRES_GPIO_Port, PRES_Pin, GPIO_PIN_RESET);
}

//----------------------------
void Encoder_DIR(bool high)
{
	if (high)
	{
		HAL_GPIO_WritePin(DIR_GPIO_Port, DIR_Pin, GPIO_PIN_SET);
	}
	else
	{			
		HAL_GPIO_WritePin(DIR_GPIO_Port, DIR_Pin, GPIO_PIN_RESET);
	}
}

//----------------------------
void EncoderSSI_init(void)
{
	rdata_prev[0] = 0;
	rdata_prev[1] = 0;
	rdata_prev[2] = 0;
	rdata_prev[3] = 0;
	HAL_GPIO_WritePin(SDE_GPIO_Port, SDE_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(SRE_GPIO_Port, SRE_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(PRES_GPIO_Port, PRES_Pin, GPIO_PIN_RESET);
	Encoder_DIR(true);
	Encoder_SET();
	SetTimerDec(ENCODER_TXD, 500);
}
char message[64];
//----------------------------
void EncoderSSI_executor(void)
{
	if (IsEndTimerDec(ENCODER_TXD) == true)
	{
		/*uint8_t _sdata[4];
		_sdata[0] = 0;
		_sdata[1] = 0;
		_sdata[2] = 0;
		_sdata[3] = 0;*/
		uint8_t _rdata[4];
		_rdata[0] = 0;
		_rdata[1] = 0;
		_rdata[2] = 0;
		_rdata[3] = 0;
		//	SetTimerDec(ENCODER_TXD, 50);	
		SetTimerDec(ENCODER_TXD, 15);
		//	while (1)
		//	{
		//#ifndef TEST_ANAL_NO_EXPENDED				  	
		HAL_StatusTypeDef _result = encoder_rx_receive(_rdata, 3);		
		if (_result != HAL_OK)
		{
			//Error_Handler();  
			return;
		}	
		if ((_rdata[0] != rdata_prev[0]) || (_rdata[1] != rdata_prev[1]) || (_rdata[2] != rdata_prev[2]))
		{							
			if ((_rdata[2] & 0xC0) != 0)
			{
				HAL_Delay(10);
				_result = encoder_rx_receive(_rdata, 3);		
				if (_result != HAL_OK)
				{
					//Error_Handler();  
					return;
				}
				if ((_rdata[2] & 0xC0) != 0)
				{
			//		return;
					_rdata[2] &= 0x3f;
				}
			}
		}
			
		rdata_prev[0] = _rdata[0];
		rdata_prev[1] = _rdata[1];
		rdata_prev[2] = _rdata[2];
		_rdata[0] &= 0x7f;
		uint _uintTemp  = (uint)_rdata[0] * 256 + (uint)_rdata[1];
		Encoder_last_data  =  grayToBinary32(_uintTemp);
		Encoder_last_data = 32768 - Encoder_last_data;
		//sprintf(&message[0], "JO:%3d,%3d\r", Encoder_last_data, encoder_prev_data);
	//	USBH_send(&message[0], strlen(&message[0])+1);
		//uint16_t _encoder_last_data; 
		int32_t _diffRaw = 0;
			
		int _flag = 1;

		int _diff = abs(Encoder_last_data - encoder_prev_data);
		if (_diff > 1)
		{
		/*		if ((_diff > 120) && (_diff < 1000))
				{
					if (Encoder_last_data > encoder_prev_data)
					{									
						EncoderDegrea = (uint16_t)(Encoder_last_data - _diff / 2);
						if (EncoderDegrea <=  encoder_prev_data)
						{
							_flag = 0;
						}
				}
				else
				{
					EncoderDegrea = (uint16_t)(Encoder_last_data + _diff / 2);
					if (EncoderDegrea >=  encoder_prev_data)
					{
						_flag = 0;
					}					
				}
				if (_flag == 1)
				{									
					AnaIn_force_sended();	
				}
			}*/	
			EncoderDegrea = (uint16_t)Encoder_last_data;				
			AnaIn_force_sended();	
			encoder_prev_data = Encoder_last_data;
		}
		//else
		//{
		//	encoder_remain_data = Encoder_last_data - encoder_prev_data;
		//}
		//encoder_prev_data = Encoder_last_data;
	}	
}


//----------------------------
/*void EncoderSSI_receive(void)
{
	if (IsEndTimerDec(ENCODER_TXD) == true)
	{
		uint8_t _data[2];
		_data[0] = 0x55;
		_data[1] = 0xAA;
		HAL_StatusTypeDef _result = encoder_tx_send(_data, 2);
		if (_result != HAL_OK)
		{
			return;
		}
		SetTimerDec(ENCODER_TXD, 20);		
	}
}*/

